/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author alexa
 */
public class BrugerIkkeFundetException extends RuntimeException {
    
    /**
     * String holding the error message 
    */
    private final String message;
    
    /**
     * The constructor of an ItemNotFoundException
     * @param mess error message to be saved
     */
    public BrugerIkkeFundetException(String mess) {
        this.message = mess;
    }
    
    /**
     * Gives the error message associated to the exception
     * @return the message corresponding to the error occurred
     */
    @Override
    public String getMessage() {
        return message;
    }
    
    
}
