/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author alexa
 */
public class Elbil {

    private String billede_url;
    private String mærke;
    private String model;
    private String pris;
    private int sæder;
    private int rækkevidde;
    private String ladetid_hjemme;
    private String ladetid_ude;

    public Elbil(String mærke, String model, String pris, int sæder,
            int rækkevidde, String ladetid_hjemme, String ladetid_ude) {

        this.billede_url = billede_url;
        this.mærke = mærke;
        this.model = model;
        this.pris = pris;
        this.sæder = sæder;
        this.rækkevidde = rækkevidde;
        this.ladetid_hjemme = ladetid_hjemme;
        this.ladetid_ude = ladetid_ude;

    }

    public String getBillede_url() {
        return billede_url;
    }
    public void setBillede_url(String billede_url) {
        this.billede_url = billede_url;
    }

    public String getModel() {
        return model;
    }

    public String getMærke() {
        return mærke;
    }

    public String getPris() {
        return pris;
    }

    public int getSæder() {
        return sæder;
    }

    public int getRækkevidde() {
        return rækkevidde;
    }

    public String getLadetid_hjemme() {
        return ladetid_hjemme;
    }

    public String getLadetid_ude() {
        return ladetid_ude;
    }

}
