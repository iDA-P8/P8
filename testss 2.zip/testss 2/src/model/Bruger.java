/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Bruger { 

    private String fornavn;
    private String efternavn;
    private String email;
    private String kodeord;
    
    private Behov behov;

    public Bruger(String fornavn, String efternavn, String email, String kodeord) {
        this.fornavn = fornavn; 
        this.efternavn = efternavn;
        this.email = email;
        this.kodeord = kodeord;
        this.behov = new Behov();
    }

    public String getFornavn() {
        return fornavn;
    }
    public void setFornavn(String brugerFornavn) {
        fornavn = brugerFornavn;
    }
    
    public String getEfternavn() {
        return efternavn;
    }
    public void setEfternavn(String brugerefternavn) {
        efternavn = brugerefternavn;
    }
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String brugerEmail) {
        email = brugerEmail;
    }
    
    public String getKodeord() {
        return kodeord;
    }
    public void setKodeord(String brugerKodeord) {
        kodeord = brugerKodeord;
    }

    public Behov getBehov() {
        return behov;
    }
    
    public void indsætBehovTilDB() {
        
            // DB connection:
            String url = "jdbc:mysql://127.0.0.1:3306/elbilstesten?useTimezone=true&serverTimezone=UTC";
            String username = "root";
            String password = "";

            Connection dbCon = null;

            System.out.println("Connecting database...");

        try {
            
            // Forbered data til insert statement fra brugerens besvarelser:
            int kørsel_behov = this.behov.getBesvarelser().get(0).getSvar_hvis_int();
            String længere_end_500_km = this.behov.getBesvarelser().get(1).getSvar_hvis_string();
            String bopæl_behov = this.behov.getBesvarelser().get(2).getSvar_hvis_string();
            String antal_passagerer = this.behov.getBesvarelser().get(3).getSvar_hvis_string();
            String anhængertræk_behov = this.behov.getBesvarelser().get(4).getSvar_hvis_string();
            String struktureret_person = this.behov.getBesvarelser().get(5).getSvar_hvis_string();
            
            // getting database Connection to MySQL server
            dbCon = DriverManager.getConnection(url, username, password);            
    
            String txtSQL = "UPDATE bruger SET \n" +
                    "kørsel_behov = ?,\n" +
                    "idLængere_end_500_km = (SELECT idLængere_end_500_km FROM længere_end_500_km WHERE længere_end_500_km = ?),\n" +
                    "idBopæl_behov = (SELECT idBopæl FROM bopæl WHERE bopæl_type = ?),\n" +
                    "idAntal_passagerer_behov = (SELECT idAntal_passagerer FROM antal_passagerer WHERE antal_passagerer = ?),\n" +
                    "idAnhængertræk_behov = (SELECT idAnhængertræk FROM anhængertræk WHERE anhængertræk_afhængig = ?),\n" +
                    "idStruktureret_person_behov = (SELECT idStruktureret_person FROM struktureret_person WHERE struktureret_person = ?),\n" +
                    "idElbil_match = (SELECT idElbil FROM elbil WHERE model = ?),\n" +
                    "score = ?,\n" +
                    "vw_scoreSamlet = ?,\n" +
                    "peugeot_scoreSamlet = ?,\n" +
                    "tesla_scoreSamlet = ?,\n" +
                    "audi_scoreSamlet = ?\n" +
                    "WHERE first_name = ? AND last_name = ?";
            
            // Execute update statement
            PreparedStatement preparedStmt = dbCon.prepareStatement(txtSQL);
            preparedStmt.setInt(1, kørsel_behov);
            preparedStmt.setString(2, længere_end_500_km);
            preparedStmt.setString(3, bopæl_behov);
            preparedStmt.setString(4, antal_passagerer);
            preparedStmt.setString(5, anhængertræk_behov);
            preparedStmt.setString(6, struktureret_person);
            preparedStmt.setString(7, this.getBehov().getElbil().getModel());
            preparedStmt.setInt(8, this.getBehov().getScore());
            preparedStmt.setInt(9, this.getBehov().getVw_scoreSamlet());
            preparedStmt.setInt(10, this.getBehov().getPeugeot_scoreSamlet());
            preparedStmt.setInt(11, this.getBehov().getTesla_scoreSamlet());
            preparedStmt.setInt(12, this.getBehov().getAudi_scoreSamlet());
            preparedStmt.setString(13, this.fornavn);
            preparedStmt.setString(14, this.efternavn);
            
            preparedStmt.execute();            

        
            dbCon.close();
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }        
        
        
    }
    
    
    
}
