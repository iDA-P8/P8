/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Bruger { 

    private String fornavn;
    private String efternavn;
    private String email;
    private String kodeord;
    
    private Behov behov;

    public Bruger(String fornavn, String efternavn, String email, String kodeord) {
        this.fornavn = fornavn; 
        this.efternavn = efternavn;
        this.email = email;
        this.kodeord = kodeord;
        this.behov = new Behov();
    }

    public String getFornavn() {
        return fornavn;
    }
    public void setFornavn(String brugerFornavn) {
        fornavn = brugerFornavn;
    }
    
    public String getEfternavn() {
        return efternavn;
    }
    public void setEfternavn(String brugerefternavn) {
        efternavn = brugerefternavn;
    }
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String brugerEmail) {
        email = brugerEmail;
    }
    
    public String getKodeord() {
        return kodeord;
    }
    public void setKodeord(String brugerKodeord) {
        kodeord = brugerKodeord;
    }

    public Behov getBehov() {
        return behov;
    }
    
    
    
    
}
