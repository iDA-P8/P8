/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author alexa
 */
public class Behov {

    private int score;
    private Elbil elbil;

    // En brugers behovklasse har en array variabel, der indeholder besvarelserne på de seks spørgsmål i testen:
    private ArrayList<Besvarelse> besvarelser;

    public Behov() {
        besvarelser = new ArrayList<>();
    }

    public void tilføjBesvarelse(Besvarelse besvarelse, int index) {
        this.besvarelser.add(index, besvarelse);
        System.out.println("Tiføjet til index: " + besvarelser.indexOf(besvarelse));
    }

    public ArrayList<Besvarelse> getBesvarelser() {
        return besvarelser;
    }

    public void udregnScore() {
        for (Besvarelse besvarelse : besvarelser) {
            this.score = this.score + besvarelse.getScore();
        }

        // Tag den samlede score fra alle besvarelser(spørgsmål 1, 2, 3 og 6) og divider med fire:
        this.score = this.score / 4;
    }

    public int getScore() {
        return score;
    }

    public void matchElbil(ArrayList<Elbil> elbilbase) {
        // Akkumuler alle scorer fra de fire elbiler og find den med den højeste:
        int vw_scoreSamlet = 0;
        int peugeot_scoreSamlet = 0;
        int tesla_scoreSamlet = 0;
        int audi_scoreSamlet = 0;

        for (Besvarelse besvarelse : besvarelser) {
            vw_scoreSamlet = vw_scoreSamlet + besvarelse.getVW_score();
            peugeot_scoreSamlet = peugeot_scoreSamlet + besvarelse.getPeugeot_score();
            tesla_scoreSamlet = tesla_scoreSamlet + besvarelse.getTesla_score();
            audi_scoreSamlet = audi_scoreSamlet + besvarelse.getAudi_score();
        }

        int max = vw_scoreSamlet;
        this.elbil = elbilbase.get(0);

        if (peugeot_scoreSamlet > max) {
            max = peugeot_scoreSamlet;
            this.elbil = elbilbase.get(1);
        }
        if (tesla_scoreSamlet > max) {
            max = tesla_scoreSamlet;
            this.elbil = elbilbase.get(2);
        }
        if (audi_scoreSamlet > max) {
            max = audi_scoreSamlet;
            this.elbil = elbilbase.get(3);
        }
    }

    public Elbil getElbil() {
        return elbil;
    }

    // SLET INDEN AFLEVERING
    public void udprintAlleScore(String navn) {

        int scoreSamlet = 0;
        int vw_scoreSamlet = 0;
        int peugeot_scoreSamlet = 0;
        int tesla_scoreSamlet = 0;
        int audi_scoreSamlet = 0;

        for (Besvarelse besvarelse : besvarelser) {
            scoreSamlet = scoreSamlet + besvarelse.getScore();
            vw_scoreSamlet = vw_scoreSamlet + besvarelse.getVW_score();
            peugeot_scoreSamlet = peugeot_scoreSamlet + besvarelse.getPeugeot_score();
            tesla_scoreSamlet = tesla_scoreSamlet + besvarelse.getTesla_score();
            audi_scoreSamlet = audi_scoreSamlet + besvarelse.getAudi_score();
        }

        System.out.println(navn + " har en samlet score på: " + scoreSamlet);
        System.out.println(navn + " har en samlet vw_score på: " + vw_scoreSamlet);
        System.out.println(navn + " har en samlet peugeoet_score på: " + peugeot_scoreSamlet);
        System.out.println(navn + " har en samlet tesla_score på: " + tesla_scoreSamlet);
        System.out.println(navn + " har en samlet audi_score på: " + audi_scoreSamlet);

    }

}
