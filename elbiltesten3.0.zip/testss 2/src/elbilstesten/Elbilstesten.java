/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elbilstesten;

import gui.Forside;
import gui.Resultatside;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Elbilstesten extends Application {

    Font academySansBold45 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 45);
    Font academySans24 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 24);
    Font academySansLightItalic18 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-LightItalic.ttf"), 18);
    Font academySansLight18 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Light.ttf"), 18);
    Font academySansDemiBold16 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-DemiBold.ttf"), 16);

    @Override
    public void start(Stage primaryStage) throws Exception {

        BrugerBase brugerBase = new BrugerBase();
        Bruger alex = new Bruger("Alexander", "Bornefeldt", "testBruger1@test.dk", "password1");
            brugerBase.tilføjBruger(alex);
        Bruger kense = new Bruger("Kenny", "Karlsson", "testBruger2@test.dk", "password2");
            brugerBase.tilføjBruger(kense);
        Bruger jakse = new Bruger("Jakob", "Hummelgaard", "testBruger3@test.dk", "password3");
            brugerBase.tilføjBruger(jakse);
        Bruger aliAK = new Bruger("Ali", "Quibassi", "testBruger4@test.dk", "password4");
            brugerBase.tilføjBruger(aliAK);
            
            brugerBase.erOprettet("testBruger4@test.dk", "password4");
            
        
        /* 
            - Lav ElbilBasen hvor vi gemmer og tilgår elbilerne fra
            - Lav de fire elbilsmodeller, som vi matcher brugerne op med
        */
        // ElbilBase elbilBase = new ElbilBase();
        ArrayList<Elbil> elbilBase = new ArrayList<>();
            Elbil vw_up = new Elbil("/billeder/vw_eup.jpg", "Volkswagen", "e-Up!", "162.995", 4,
                                    258, "Ca. 5 timer", "Ca. 60 minutter");
                elbilBase.add(vw_up);
            Elbil peugeot_e208 = new Elbil("/billeder/peugeot_e208.jpg", "Peugeot", "e-208", "229.990", 5,
                                    340, "Ca. 5,25 timer", "Ca. 55 minutter");
                elbilBase.add(peugeot_e208);
            Elbil tesla_model3 = new Elbil("/billeder/tesla_model3.jpg", "Tesla", "Model 3", "449.900", 5,
                                    560, "Ca. 12 timer", "Ca. 30 minutter");
                elbilBase.add(tesla_model3);
            Elbil audi_etron = new Elbil("/billeder/audi_etron.jpg", "Audi", "e-tron", "569.990", 5,
                                    429, "Ca. 8,5 timer", "Ca. 60 minutter");
                elbilBase.add(audi_etron);
        
        Forside forside = new Forside(elbilBase, brugerBase, null);
//        Forside1 forside1 = new Forside1();
//        LoginSide login = new LoginSide(brugerbase);
//        TestSide1 testside1 = new TestSide1();
//        TestSide2 testside2 = new TestSide2();
//        TestSide6 testside6 = new TestSide6();
//        Resultatside resultat = new Resultatside(elbilBase, brugerBase, null);

        Scene scene = new Scene(forside, 1280, 720);

        primaryStage.setTitle("Elbilsten");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String args[]) {
  
        launch(args);
        
        
    }
}
