/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Resultatside extends BorderPane {

    Label overskrift, rubrik, skalarubrik, biloverskrift, bilrubrik,
            dagligKørselOverskrift, dagligKørselIntro, dagligKørselUddybning,
            elbilenOverskrift, elbilenIntro, elbilenUddybning,
            ladningOverskrift, ladningIntro, ladningUddybning,
            opladningOverskrift, opladningForklaring, kmGridOverskrift,
            kmGridForklaring;

    Label bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde;

    Label kol1, kol2, kol3, ræk1, ræk2, ræk3, ræk4, celB1, celB2, celB3, celC1,
            celC2, celC3, celC4, celD3, celD2, celD4;

    Label A2, A3, A4, A5, B1, B2, B3, B4, B5, C1, C2, C3;

    Rectangle skalaFarvet, skalaGrå, baggrundGridpane;

    Image elbil_billede, spørgsmålstegn_billede, ladekort_billede;

    ImageView elbil_match, spørgsmålstegn1, spørgsmålstegn2, ladekort;

    Button tilbage;

    Tooltip tooltipRækkevidde, tooltipHjemme, tooltipUde;

    VBox resultat, tilbageBox, bilForklaringBox, bil, bilbillede, dagligKørselBox,
            kmGridVbox, elbilenBox, opladningBox, opladningTabelVbox, ladekortBox;

    GridPane pointGrid, topGrid, bilGrid, kmGrid, opladningGrid;

    StackPane skalaPane;

    Tab dagligKørselTab, elbilenTab, opladningTab;
    TabPane tabpane;

    BorderPane dagligKørselBorderPane, elbilenBorderPane, opladningBorderPane;

    public Resultatside(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        // model
        bruger.getBehov().udregnScore();
        System.out.println(bruger.getFornavn() + "'s score er: " + bruger.getBehov().getScore() + " ud af 100");
        bruger.getBehov().matchElbil(elbilBase);
        System.out.println(bruger.getFornavn() + " anbefaler vi en " + bruger.getBehov().getElbil().getMærke() + " " + bruger.getBehov().getElbil().getModel() + " til");

        // TOPPEN AF BORDERPANE
        // Del 1: Overordnet resultatboks
        overskrift = new Label("Dit elbilresultat er:\n" + bruger.getBehov().getScore() + " ud af 100");
        overskrift.setId("overskrift-label");

        // Med testens nuværende pointsystem kan brugeren få en score på mellem 43 - 100 point.
        // Jeg foreslår at vi giver dem et ud af tre svar fordelt på intervallerne 43-60, 60-80, 81-100
        double brugerscore = bruger.getBehov().getScore();
        double skalaudregning = (100 - brugerscore) / 100;

        skalaFarvet = new Rectangle(400, 40);
        skalaFarvet.setId("farvet-skala");

        skalaGrå = new Rectangle((400 * skalaudregning), 40);
        skalaGrå.setId("graa-skala");

        skalaPane = new StackPane(skalaFarvet, skalaGrå);
        skalaPane.setId("skala-pane");

        StackPane.setAlignment(skalaFarvet, Pos.CENTER);
        StackPane.setAlignment(skalaGrå, Pos.CENTER_RIGHT);

        skalarubrik = new Label("Elbilresultatet viser hvor godt en elbil passer til dig på en skala fra 0 til 100.");
        skalarubrik.setId("skala-forklaring");

        rubrik = new Label();
        rubrik.setId("forklaring-label");

        if (bruger.getBehov().getScore() <= 60) {
            rubrik.setText("Når du har scoret " + bruger.getBehov().getScore() + " "
                    + "point betyder det, at der er flere væsentlige faktorer, som "
                    + "du skal være opmærksom på, der gør, at en elbil måske ikke "
                    + "er det bedste valg for dig.\nLæs mere om disse længere nede på siden.");
        } else if (bruger.getBehov().getScore() > 60 && bruger.getBehov().getScore() <= 80) {
            rubrik.setText("Når du har scoret " + bruger.getBehov().getScore() + " "
                    + "point betyder det, at en elbil kan være det rigtige valg "
                    + "til at opfylde dine kørselsbehov, men der er flere faktorer, "
                    + "som du skal være opmærksom på.\nLæs mere om disse længere nede på siden. ");
        } else if (bruger.getBehov().getScore() > 80) {
            rubrik.setText("Når du har scoret " + bruger.getBehov().getScore() + " "
                    + "point betyder det, at en elbil passer rigtig godt til dig "
                    + "og dine behov.\nLæs dine specifikke resultater nederst og "
                    + "bliv klogere på, hvor godt en elbil passer til dig.");
        }

        tilbage = new Button("Tilbage til forsiden");
        tilbage.setOnAction((ActionEvent event) -> {
            Forside forside = new Forside(elbilBase, brugerBase, bruger);
            getScene().setRoot(forside);
        });

        tilbageBox = new VBox(tilbage);
        tilbageBox.setId("vbox-tilbage-knap");

        resultat = new VBox(overskrift, skalaPane, skalarubrik, rubrik, tilbageBox);
        resultat.setAlignment(Pos.TOP_CENTER);
        resultat.setId("vbox-resultat");

        // Del 3: Forslag til elbil
        biloverskrift = new Label("Bedste elbil til dig");
        biloverskrift.setId("overskrift-label");

        bilrubrik = new Label("På baggrund af dine svar i testen anbefaler vi en "
                + bruger.getBehov().getElbil().getMærke() + " " + bruger.getBehov().getElbil().getModel()
                + " som det bedste bilkøb til dig, hvis du vælger at købe en elbil.");
        bilrubrik.setId("rubrik-label");

        elbil_billede = new Image(getClass().getResourceAsStream(bruger.getBehov().getElbil().getBillede_url()));
        elbil_match = new ImageView(elbil_billede);
        elbil_match.setFitHeight(150);
        elbil_match.setPreserveRatio(true);
        elbil_match.setSmooth(true);
        elbil_match.setCache(true);

        bilnavn = new Label(bruger.getBehov().getElbil().getMærke() + " " + bruger.getBehov().getElbil().getModel());
        bilnavn.setId("bilnavn-label");

        pris = new Label("Fra kr. " + bruger.getBehov().getElbil().getPris());
        pris.setId("pris-label");

        sæder = new Label("Antal sæder: " + bruger.getBehov().getElbil().getSæder());
        sæder.setId("bilinfo-label");

        rækkevidde = new Label("Rækkevidde: " + bruger.getBehov().getElbil().getRækkevidde() + " km");
        rækkevidde.setId("bilinfo-label");

        ladetidHjemme = new Label("Ladetid hjemme: " + bruger.getBehov().getElbil().getLadetid_hjemme());
        ladetidHjemme.setId("bilinfo-label");

        ladetidUde = new Label("Ladetid ude: " + bruger.getBehov().getElbil().getLadetid_ude());
        ladetidUde.setId("bilinfo-label");

        bil = new VBox(bilnavn, pris, sæder, rækkevidde, ladetidHjemme, ladetidUde);
        bil.getStyleClass().add("vbox");

        bilbillede = new VBox(elbil_match);
        bilbillede.setId("bilbillede-vbox");

        bilGrid = new GridPane();
        bilGrid.setId("bilgrid");

        bilGrid.add(bilbillede, 0, 1);
        bilGrid.add(bil, 1, 1);

        bilForklaringBox = new VBox(biloverskrift, bilGrid, bilrubrik);
        bilForklaringBox.setId("vbox-bil-resultat");

        // Tilføj Del 1, 2 og 3 til toppen af borderpane via en gridpane      
        topGrid = new GridPane();

        topGrid.add(resultat, 0, 0);
        topGrid.add(bilForklaringBox, 1, 0);

        topGrid.getColumnConstraints().add(new ColumnConstraints(617));
        topGrid.getColumnConstraints().add(new ColumnConstraints(618));

        topGrid.setId("topgrid");

        setTop(topGrid);

        //TABPANE
        dagligKørselBorderPane = new BorderPane();

        // TAB 1: DAGLIG KØRSEL
        dagligKørselOverskrift = new Label("Daglig Kørsel");
        dagligKørselOverskrift.setId("overskrift-label");

        dagligKørselIntro = new Label(bruger.getBehov().getBesvarelser().get(0).getSvar_uddybning());
        dagligKørselUddybning = new Label(bruger.getBehov().getBesvarelser().get(4).getSvar_uddybning());

        dagligKørselBox = new VBox(dagligKørselOverskrift, dagligKørselIntro, dagligKørselUddybning);
        dagligKørselBox.setId("vbox-tekst-tabs");

        // KM TABEL
        spørgsmålstegn_billede = new Image(getClass().getResourceAsStream("/billeder/info-black.png"));
        spørgsmålstegn1 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn1.setFitWidth(16);
        spørgsmålstegn1.setPreserveRatio(true);
        spørgsmålstegn1.setSmooth(true);
        spørgsmålstegn1.setCache(true);

        spørgsmålstegn2 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn2.setFitWidth(15);
        spørgsmålstegn2.setPreserveRatio(true);
        spørgsmålstegn2.setSmooth(true);
        spørgsmålstegn2.setCache(true);

        kol1 = new Label("Du kører\ndagligt");
        kol1.setId("overskrifter-label-koersel");

        kol2 = new Label("Bilens rækkevidde");
        kol2.setId("overskrifter-label-koersel");

        ræk1 = new Label("Daglig kørsel");

        ræk2 = new Label("Rækkevidde tilovers ved daglig kørsel");
        ræk2.setId("summary-label");

        celB1 = new Label(bruger.getBehov().getBesvarelser().get(0).getSvar_hvis_int() + " km");

        celC1 = new Label(bruger.getBehov().getElbil().getRækkevidde() + " km", spørgsmålstegn1);

        int kmTilovers = bruger.getBehov().getElbil().getRækkevidde() - (bruger.getBehov().getBesvarelser().get(0).getSvar_hvis_int());
        celC2 = new Label(kmTilovers + " km");
        celC2.setId("summary-label");

        tooltipRækkevidde = new Tooltip("Dette er bilens teoretiske rækkevidde. Du"
                + "kan ikke opnå\n denne rækkevidde ved normal kørsel. Bilens reelle\n "
                + "rækkevidde er 50-150 km mindre.");
        tooltipRækkevidde.setShowDelay(Duration.millis(200));
        tooltipRækkevidde.setShowDuration(Duration.INDEFINITE);

        celC1.setTooltip(tooltipRækkevidde);

        baggrundGridpane = new Rectangle(450, 50, Color.LIGHTGREY);

        kmGrid = new GridPane();
        kmGrid.add(baggrundGridpane, 0, 2, 3, 1);
        kmGrid.add(kol1, 1, 0);
        kmGrid.add(kol2, 2, 0);
        kmGrid.add(ræk1, 0, 1);
        kmGrid.add(ræk2, 0, 2);
        kmGrid.add(celB1, 1, 1);
        kmGrid.add(celC1, 2, 1);
        kmGrid.add(celC2, 2, 2);

        kmGrid.getColumnConstraints().add(new ColumnConstraints(170));
        kmGrid.getColumnConstraints().add(new ColumnConstraints(140));
        kmGrid.getColumnConstraints().add(new ColumnConstraints(140));

        kmGrid.getStylesheets().add("/css/tabeller.css");
        kmGrid.getStyleClass().add("grid-pane");

        kmGridOverskrift = new Label("Rækkevidde");
        kmGridOverskrift.setId("overskrift-label");
        kmGridForklaring = new Label("Se forholdet mellem din daglige kørsel og "
                + "rækkevidden for en " + bruger.getBehov().getElbil().getMærke()
                + " " + bruger.getBehov().getElbil().getModel() + ".");

        kmGridVbox = new VBox(kmGridOverskrift, kmGridForklaring, kmGrid);
        kmGridVbox.setId("vbox-tekst-tabs");

        dagligKørselTab = new Tab("Daglig kørsel");
        dagligKørselTab.setContent(dagligKørselBorderPane);
        dagligKørselBorderPane.setId("borderpane-daglig-koersel");

        dagligKørselBorderPane.setLeft(dagligKørselBox);
        dagligKørselBorderPane.setRight(kmGridVbox);

        // ELBILEN TAB
        elbilenBorderPane = new BorderPane();

        //LEFT
        elbilenOverskrift = new Label(bruger.getBehov().getElbil().getMærke() + " " + bruger.getBehov().getElbil().getModel());
        elbilenOverskrift.setId("overskrift-label");

        elbilenIntro = new Label("Vi har anbefalet en Audi e-Tron som den elbil, "
                + "der passer bedst til dig og dine behov. En Audi e-Tron har "
                + "en rækkevidde på op til 429 km, hvilket lader dig klare dine "
                + "daglige køreture, mens du samtidig kan klare længere ture "
                + "uden at skulle lade bilen op. Det er en meget rummelig bil, "
                + "som komfortabelt kan transportere op til 5 passagerer.\n"
                + "\n" + "En Audi e-Tron kan oplades med en ladeboks på din "
                + "bopæl, eller med en hurtiglader på tankstationer, "
                + "supermarkeder eller lignende. Til højre kan du se "
                + "eksempler på hvor mange kilometer, som du vil kunne "
                + "opnå i rækkevidde, ud fra hvor lang tid du oplader bilen.");

        elbilenBox = new VBox(elbilenOverskrift, elbilenIntro);
        elbilenBox.setId("vbox-tekst-tabs");

        //RIGHT
        spørgsmålstegn_billede = new Image(getClass().getResourceAsStream("/billeder/info-black.png"));
        spørgsmålstegn1 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn1.setFitWidth(16);
        spørgsmålstegn1.setPreserveRatio(true);
        spørgsmålstegn1.setSmooth(true);
        spørgsmålstegn1.setCache(true);

        spørgsmålstegn2 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn2.setFitWidth(16);
        spørgsmålstegn2.setPreserveRatio(true);
        spørgsmålstegn2.setSmooth(true);
        spørgsmålstegn2.setCache(true);

        A2 = new Label("Opladning i 0:30 time");
        A2.setId("overskrifter-label-opladning");

        A3 = new Label("Opladning i 1:00 time");
        A3.setId("overskrifter-label-opladning");

        A4 = new Label("Opladning i 5:00 timer");
        A4.setId("overskrifter-label-opladning");

        A5 = new Label("Opladning i 8:30 timer");
        A5.setId("overskrifter-label-opladning");

        B1 = new Label("Opladning hjemme", spørgsmålstegn1);
        B1.setContentDisplay(ContentDisplay.LEFT);

        B2 = new Label("25 km");
        B3 = new Label("50 km");
        B4 = new Label("252 km");
        B5 = new Label("429 km");

        C1 = new Label("Opladning ude", spørgsmålstegn2);
        C1.setContentDisplay(ContentDisplay.LEFT);

        C2 = new Label("215 km");
        C3 = new Label("429 km");

        tooltipHjemme = new Tooltip("Tallene er baseret på, at du lader bilen op "
                + "ved hjælp af\nen ladeboks på din bopæl, som kan lade med 11 kW.");
        tooltipHjemme.setShowDelay(Duration.millis(200));
        tooltipHjemme.setShowDuration(Duration.INDEFINITE);

        tooltipUde = new Tooltip("Tallene er baseret på, at du lader bilen op "
                + "ved hjælp af\nen hurtiglader. Hurtigladere kan findes ved tankstationer,\n"
                + "supermarkeder, lufthavne og lignende og kan lade med 50 kW.");
        tooltipUde.setShowDelay(Duration.millis(200));
        tooltipUde.setShowDuration(Duration.INDEFINITE);

        B1.setTooltip(tooltipHjemme);
        C1.setTooltip(tooltipUde);

        opladningGrid = new GridPane();

        opladningGrid.add(A2, 1, 0);
        opladningGrid.add(A3, 2, 0);
        opladningGrid.add(A4, 3, 0);
        opladningGrid.add(A5, 4, 0);
        opladningGrid.add(B1, 0, 1);
        opladningGrid.add(B2, 1, 1);
        opladningGrid.add(B3, 2, 1);
        opladningGrid.add(B4, 3, 1);
        opladningGrid.add(B5, 4, 1);
        opladningGrid.add(C1, 0, 2);
        opladningGrid.add(C2, 1, 2);
        opladningGrid.add(C3, 2, 2);

        for (int i = 0; i < 5; i++) {
            if (i < 1) {
                ColumnConstraints col = new ColumnConstraints(175);
                opladningGrid.getColumnConstraints().add(col);
            } else {
                ColumnConstraints col = new ColumnConstraints(110);
                opladningGrid.getColumnConstraints().add(col);
            }
        }

        opladningGrid.getStylesheets().add("/css/tabeller.css");
        opladningGrid.getStyleClass().add("grid-pane");

        opladningOverskrift = new Label("Ladetid og rækkevidde");
        opladningOverskrift.setId("overskrift-label");
        opladningForklaring = new Label("I tabellen kan du se forholdet mellem ladetid"
                + " og rækkevidde for en " + bruger.getBehov().getElbil().getMærke() + " " + bruger.getBehov().getElbil().getModel());

        opladningTabelVbox = new VBox(opladningOverskrift, opladningForklaring, opladningGrid);
        opladningTabelVbox.setId("vbox-tekst-tabs");

        elbilenBorderPane.setLeft(elbilenBox);
        elbilenBorderPane.setRight(opladningTabelVbox);

        elbilenTab = new Tab(bruger.getBehov().getElbil().getMærke() + " " + bruger.getBehov().getElbil().getModel());
        elbilenTab.setContent(elbilenBorderPane);

        // OPLADNING TAB
        opladningBorderPane = new BorderPane();

        ladningOverskrift = new Label("Opladning");
        ladningOverskrift.setId("overskrift-label");

        ladningIntro = new Label(bruger.getBehov().getBesvarelser().get(2).getSvar_uddybning());

        ladningUddybning = new Label(bruger.getBehov().getBesvarelser().get(1).getSvar_uddybning());

        ladekort_billede = new Image(getClass().getResourceAsStream("/billeder/ladekort.jpg"));
        ladekort = new ImageView(ladekort_billede);
        ladekort.setFitHeight(250);
        ladekort.setPreserveRatio(true);
        ladekort.setSmooth(true);
        ladekort.setCache(true);
        ladekort.setOnMouseClicked(e -> {
            if (Desktop.isDesktopSupported()) {
                try {
                    Desktop.getDesktop().browse(new URI("https://www.plugshare.com/"));
                } catch (IOException e1) {
                    e1.printStackTrace();
                } catch (URISyntaxException e1) {
                    e1.printStackTrace();
                }
            }
        });

        opladningBox = new VBox(ladningOverskrift, ladningIntro, ladningUddybning);
        opladningBox.setId("vbox-tekst-tabs");

        ladekortBox = new VBox(ladekort);
        ladekortBox.setId("vbox-ladekort");

        opladningTab = new Tab("Opladning");

        opladningBorderPane.setLeft(opladningBox);
        opladningBorderPane.setRight(ladekortBox);

        opladningTab.setContent(opladningBorderPane);

        tabpane = new TabPane(dagligKørselTab, elbilenTab, opladningTab);
        tabpane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        this.getStylesheets().add("/css/resultatside.css");

        setCenter(tabpane);

    }

}
