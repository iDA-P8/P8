/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;
import model.Besvarelse;

/**
 *
 * DAGLIG KØRSEL
 *
 * @author jakobbakhummelgaard
 */
public class TestSide1 extends BorderPane {

    Label overskrift, underoverskrift, progress, spørgsmål, km, fejlbesked, faktaboks;

    TextField dagligKørselTextField;
    
    Button tilbage, næste;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox, faktaVbox;

    public TestSide1(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        System.out.println("Brugerens navn vi har med i testen er: " + bruger.getFornavn() + bruger.getEfternavn());
        
        final BooleanProperty firstTime = new SimpleBooleanProperty(true);
        
        
        
        // Top of borderpane
        overskrift = new Label("Elbiltesten");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om dine daglige kørselsmønstre");
        underoverskrift.setId("underoverskrift");
        
        progressbar = new ProgressBar(0.145);
        progressbar.setId("progressbar");
        
        progress = new Label("14%", progressbar);

        topBox = new VBox(overskrift, underoverskrift, progress);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Hvor mange kilometer kører du i gennemsnit til daglig?     ");

        dagligKørselTextField = new TextField();
        dagligKørselTextField.setPromptText("Indtast kørsel pr. dag");
        dagligKørselTextField.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus();
                firstTime.setValue(false);
            }
        });

        dagligKørselTextField.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            if (!newValue.matches("\\d*")) {
                dagligKørselTextField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        km = new Label("km");
        km.setId("km-label");

        fejlbesked = new Label("Du skal indtaste et helt tal");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("Vidste du, at en elbils reelle rækkevidde "
                        + "afhænger af mange forskellige faktorer? Din kørestil, "
                        + "temperaturen udenfor og hvor meget vægt du har i bilen "
                        + "påvirker bl.a. bilens rækkevidde.");    
        faktaboks.setId("faktaboks-label");
        
        faktaVbox = new VBox(faktaboks);
        faktaVbox.getStyleClass().add("vbox-fakta");

        centerGrid = new GridPane();
        
        centerGrid.add(spørgsmål, 0, 0);
        centerGrid.add(dagligKørselTextField, 1, 0);
        centerGrid.add(km, 2, 0);
        centerGrid.add(fejlbesked, 1, 1);
        centerGrid.add(faktaVbox, 0, 2, 3, 1);
        
        centerGrid.getRowConstraints().add((new RowConstraints(100)));
        centerGrid.getRowConstraints().add((new RowConstraints(20)));
        centerGrid.getRowConstraints().add((new RowConstraints(240)));
        
        centerGrid.setId("centergrid");

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            Forside forside = new Forside(elbilBase, brugerBase, bruger);
            getScene().setRoot(forside);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if (dagligKørselTextField.getText().isEmpty()) {
                fejlbesked.setVisible(true);
            } else {
                
                // Ryd først indexet i arraylisten med besvarelser:
                if( bruger.getBehov().getBesvarelser().size() == 1 ) {
                bruger.getBehov().getBesvarelser().remove(0);
                }
                
                // Hvis der er en korrekt værdi i feltet, opret et besvarelse-objekt og set scorerne:
                int dagligKørsel = Integer.parseInt(dagligKørselTextField.getText());
                Besvarelse besvarelse = new Besvarelse("spørgsmål 1", dagligKørsel);
                    
                    // angiv point ud fra daglig kørte km:
                    if( dagligKørsel <= 150 ) {
                        besvarelse.tilføjTilScore(100, 100, 75, 0, 25 );
                        besvarelse.setSvar_uddybning("Da du kører under 150 "
                                + "kilometer dagligt, vil de fleste elbiler kunne "
                                + "dække dette kørselsbehov, uden at elbilen skal "
                                + "oplades. Derfor er der på baggrund af dette "
                                + "ikke behov for en elbil, som kan køre over 250 "
                                + "kilometer på en fuld opladning."); 
                    } else if( dagligKørsel >= 151 && dagligKørsel <= 300 ) {
                        besvarelse.tilføjTilScore(90, 50, 100, 25, 50 );
                        besvarelse.setSvar_uddybning("Du har angivet, at du kører "
                                + "mellem 151 og 300 kilometer dagligt. Nogle "
                                + "elbiler vil på baggrund af dette kørselsbehov "
                                + "ikke kunne klare den daglige kørsel på én "
                                + "opladning og vurderes derfor ikke lige så "
                                + "fordelagtige som de elbiler, hvis rækkevidde "
                                + "ligger indenfor intervallet.");
                    } else if( dagligKørsel >= 301 && dagligKørsel <= 500 ) {
                        besvarelse.tilføjTilScore(80, 0, 25, 100, 75 );
                        besvarelse.setSvar_uddybning("Du har angivet, at du kører "
                                + "mellem 301 og 500 kilometer dagligt. Nogle "
                                + "elbiler vil på baggrund af dette kørselsbehov "
                                + "ikke kunne klare den daglige kørsel på én "
                                + "opladning og vurderes derfor ikke lige så "
                                + "fordelagtige som de elbiler, hvis rækkevidde "
                                + "ligger indenfor intervallet.");
                    }  else if( dagligKørsel > 500 ) {
                        besvarelse.tilføjTilScore(50, 0, 0, 50, 25 );
                        besvarelse.setSvar_uddybning("Det er på nuværende tidspunkt "
                                + "de færreste elbiler, som kan køre over 500 "
                                + "kilometer på en enkelt opladning. Det er "
                                + "vigtigt at være opmærksom på dette, hvis du "
                                + "overvejer at købe en elbil, da det derfor kan "
                                + "betyde, at du vil være nødsaget til at afsætte "
                                + "tid til at oplade din elbil i løbet af dagen.");
                    }
                    
                    bruger.getBehov().tilføjBesvarelse(besvarelse, 0);  
                    
                    // *TEST* om brugeren har fået de rigtige score:
                    System.out.println("SPØRGSMÅL 1:");
                    System.out.println("Antal besvarelser i array: " + bruger.getBehov().getBesvarelser().size());
                    bruger.getBehov().udprintAlleScore( bruger.getFornavn() );
                    

                        TestSide2 testside2 = new TestSide2(elbilBase, brugerBase, bruger);
                        getScene().setRoot(testside2);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
        
    }
    

}

