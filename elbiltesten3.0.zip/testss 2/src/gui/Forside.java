package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Forside extends BorderPane {

    Label testbeskrivelse, bilbeskrivelse;

    Image spørgsmålstegn_billede;

    ImageView spørgsmålstegn1, spørgsmålstegn2;

    Button opretBrugerKnap, loginKnap, start;

    Tooltip tooltip1, tooltip2;

    VBox bundBox;
    HBox loginHB, loggetinHB, topHB;

    GridPane topGrid, centerGrid;

    /**
     * Elementer til logo
     *
     */
    Rectangle rectangle, line;
    Label systemNavn, madeBy;
    Image ikon_billede;
    ImageView ikon;
    StackPane stack;

    Bruger loggetInd;

    public Forside(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {
        this.loggetInd = bruger;

        // LOGO
        rectangle = new Rectangle(200, 90, Color.web("#66BD63"));
        line = new Rectangle(175, 2, Color.rgb(255, 255, 255));

        systemNavn = new Label("Elbiltesten");
        systemNavn.setId("systemnavn-label");

        madeBy = new Label("Fra IDAs drenge");
        madeBy.setId("madeby-label");

        ikon_billede = new Image(getClass().getResourceAsStream("/billeder/ikon.png"));
        ikon = new ImageView(ikon_billede);
        ikon.setFitWidth(25);
        ikon.setFitHeight(43);
        ikon.setPreserveRatio(true);
        ikon.setSmooth(true);
        ikon.setCache(true);

        stack = new StackPane();
        stack.getChildren().addAll(rectangle, ikon, systemNavn, line, madeBy);
        stack.setAlignment(Pos.TOP_LEFT);

        StackPane.setMargin(rectangle, new Insets(0, 0, 0, 50));
        StackPane.setMargin(ikon, new Insets(10, 0, 0, 65));
        StackPane.setMargin(systemNavn, new Insets(10, 0, 0, 95));
        StackPane.setMargin(line, new Insets(55, 0, 0, 62));
        StackPane.setMargin(madeBy, new Insets(61, 0, 0, 100));

//        Label brugerTjek = new Label();
//        if (loggetInd == null) {
//            brugerTjek.setText("Ikke logget ind");
//        } else {
//            brugerTjek.setText(loggetInd.getFornavn() + " " + loggetInd.getEfternavn());
//        }
        // Opret bruger og loginKnap
        loginKnap = new Button("Log ind");
        loginKnap.setId("login-button");
        loginKnap.setOnAction((ActionEvent event) -> {
            LoginSide loginSide = new LoginSide();
            loggetInd = loginSide.display(elbilBase, brugerBase, loggetInd);

            if (loggetInd != null) {
//                brugerTjek.setText(loggetInd.getFornavn() + " " + loggetInd.getEfternavn());
                topGrid.getChildren().remove(loginHB);
                brugerLoggetInd();

            }
        });

        opretBrugerKnap = new Button("Opret bruger");
        opretBrugerKnap.setId("opretbruger-button");
        opretBrugerKnap.setOnAction((ActionEvent event) -> {
            OpretBruger opretBruger = new OpretBruger();
            loggetInd = opretBruger.display(elbilBase, brugerBase, loggetInd);

            if (loggetInd != null) {
//                brugerTjek.setText(loggetInd.getFornavn() + " " + loggetInd.getEfternavn());
                topGrid.getChildren().remove(loginHB);

                brugerLoggetInd();
            }
        });

        loginHB = new HBox(loginKnap, opretBrugerKnap);
        loginHB.getStyleClass().add("hbox");

        topGrid = new GridPane();

        if (loggetInd == null) {
            topGrid.add(stack, 0, 0);
            topGrid.add(loginHB, 1, 0);

        } else {
            topGrid.add(stack, 0, 0);
            brugerLoggetInd();
        }

        topGrid.getColumnConstraints().add(new ColumnConstraints(640));
        topGrid.getColumnConstraints().add(new ColumnConstraints(640));

        setTop(topGrid);

        // CENTER AF BORDERPANE
        bilbeskrivelse = new Label("Eksempler på elbiler");
        bilbeskrivelse.setId("underoverskrifter");

        centerGrid = new GridPane();
        centerGrid.add(bilbeskrivelse, 0, 0);

        // Bilkort:
        int kortPlacering = 0;
        for (Elbil elbil : elbilBase) {

            // hent alle attributter til kortene
            String billede_url = elbil.getBillede_url();
            String mærke = elbil.getMærke();
            String model = elbil.getModel();
            String pris = elbil.getPris();
            int sæder = elbil.getSæder();
            int rækkevidde = elbil.getRækkevidde();
            String ladetid_hjemme = elbil.getLadetid_hjemme();
            String ladetid_ude = elbil.getLadetid_ude();

            // kald bilKort metoden og sæt værdierne efter attributterne:
            VBox vb = new VBox(bilKort(billede_url, mærke, model, pris, sæder, rækkevidde, ladetid_hjemme, ladetid_ude));

            // placer bilkortet som det næste i rækken på centerGrid:
            centerGrid.add(vb, kortPlacering, 1);
            kortPlacering = kortPlacering + 1;
        }

        centerGrid.setAlignment(Pos.CENTER);
        setCenter(centerGrid);

        // BUNDEN AF BORDERPANE
        testbeskrivelse = new Label("Find ud af om en elbil er det rette for dig");
        testbeskrivelse.setId("underoverskrifter");

        start = new Button("Start elbiltesten");
        start.setOnAction((ActionEvent event) -> {

            if (loggetInd == null) {

                OpretBruger opret = new OpretBruger();
                loggetInd = opret.display(elbilBase, brugerBase, loggetInd);

            } else {

                TestSide1 testside1 = new TestSide1(elbilBase, brugerBase, loggetInd);
                getScene().setRoot(testside1);
            }

        });

        bundBox = new VBox(testbeskrivelse, start);
        bundBox.getStyleClass().add("vbox-bottom");
        setBottom(bundBox);

        boolean testboolean = false;

        if (testboolean) {
            Button seResultat = new Button("Se dit resultat");
            Button nyTest = new Button("Tag en ny elbiltest");

            HBox bundHB = new HBox(seResultat, nyTest);
            bundHB.getStyleClass().add("hbox-bottom");

            bundBox.getChildren().removeAll(testbeskrivelse, start);
            bundBox.getChildren().addAll(bundHB);
        }

        this.getStylesheets().add("/css/forside.css");
    }
    //Constructor done

    public VBox bilKort(String img_url, String mærke, String model, String pris, int sæder,
            int rækkevidde, String ladetid_hjemme, String ladetid_ude) {

        Image billede = new Image(getClass().getResourceAsStream(img_url));
        ImageView bil_view = new ImageView(billede);
        bil_view.setFitWidth(235);
        bil_view.setPreserveRatio(true);
        bil_view.setSmooth(true);
        bil_view.setCache(true);

        Label bil_navn = new Label(mærke + " " + model);
        bil_navn.setId("bilnavn-label");

        Label bil_pris = new Label("Fra kr. " + pris);
        bil_pris.setId("pris-label");

        Label bil_sæder = new Label("Antal sæder: " + Integer.toString(sæder));

        Label bil_rækkevidde = new Label("Rækkevidde: " + Integer.toString(rækkevidde) + " km");

        // tooltip:
        spørgsmålstegn_billede = new Image(getClass().getResourceAsStream("/billeder/info-black.png"));
        spørgsmålstegn1 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn1.setFitWidth(16);
        spørgsmålstegn1.setPreserveRatio(true);
        spørgsmålstegn1.setSmooth(true);
        spørgsmålstegn1.setCache(true);

        spørgsmålstegn_billede = new Image(getClass().getResourceAsStream("/billeder/info-black.png"));
        spørgsmålstegn2 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn2.setFitWidth(16);
        spørgsmålstegn2.setPreserveRatio(true);
        spørgsmålstegn2.setSmooth(true);
        spørgsmålstegn2.setCache(true);

        Label bil_ladetidHjemme = new Label("Ladetid hjemme: " + ladetid_hjemme, spørgsmålstegn1);
        bil_ladetidHjemme.setContentDisplay(ContentDisplay.RIGHT);

        Label bil_ladetidUde = new Label("Ladetid ude: " + ladetid_ude, spørgsmålstegn2);
        bil_ladetidUde.setContentDisplay(ContentDisplay.RIGHT);

        tooltip1 = new Tooltip("Den reelle ladetid afhænger af mange faktorer.\n"
                + "Det vil tage ca. 5 timer at lade denne bil fuldt op, hvis du lader\n"
                + "med en ladeboks på din bopæl. ");
        tooltip1.setShowDelay(Duration.millis(200));
        tooltip1.setShowDuration(Duration.INDEFINITE);

        tooltip2 = new Tooltip("Dette kan opnås ved at lade med en hurtiglader.\n"
                + "Hurtigladere kan findes rundt omkring i landet og du kan på\n"
                + "kort tid få en næsten fuldt opladt bil.");
        tooltip2.setShowDelay(Duration.millis(200));
        tooltip2.setShowDuration(Duration.INDEFINITE);

        bil_ladetidUde.setTooltip(tooltip2);
        bil_ladetidHjemme.setTooltip(tooltip1);
        // tooltip slut

        VBox bilKort = new VBox(bil_view, bil_navn, bil_pris, bil_sæder, bil_rækkevidde, bil_ladetidHjemme, bil_ladetidUde);

        bilKort.getStyleClass().add("vbox");

        return bilKort;
    }

    public SplitMenuButton brugerLoggetInd() {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        SplitMenuButton brugerhåndtering = new SplitMenuButton();
        brugerhåndtering.setText(loggetInd.getFornavn() + " " + loggetInd.getEfternavn());
        brugerhåndtering.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                topGrid.requestFocus();
                firstTime.setValue(false);
            }
        });

        MenuItem rediger = new MenuItem("Min bruger");
        rediger.setOnAction((e) -> {
            System.out.println("virker");
        });

        MenuItem log_ud = new MenuItem("Log ud");
        log_ud.setOnAction((e) -> {
            loggetInd = null;
            topGrid.getChildren().removeAll(loggetinHB);
            topGrid.add(loginHB, 1, 0);
        });

        brugerhåndtering.getItems().addAll(rediger, log_ud);

        loggetinHB = new HBox(brugerhåndtering);
        loggetinHB.getStyleClass().add("hbox");

        topGrid.add(loggetinHB, 1, 0);

        return brugerhåndtering;
    }

}
