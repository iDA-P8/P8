/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Besvarelse;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * HUS ELLER LEJLIGHED
 * 
 * @author jakobbakhummelgaard
 */
public class TestSide3 extends BorderPane {

    Label overskrift, underoverskrift, progress, spørgsmål, fejlbesked, faktaboks;

    RadioButton hus, lejlighed;
    ToggleGroup boliggruppe;

    Button tilbage, næste;
    
    ProgressBar progressbar;
    AnchorPane anchorPane;
    GridPane centerGrid;
    
    HBox knapper;
    VBox topBox, faktaVbox;

    public TestSide3(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Elbiltesten");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om din boligsituation");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.435);
        progressbar.setId("progressbar");
        
        progress = new Label("43%", progressbar);
        
        topBox = new VBox(overskrift, underoverskrift, progress);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Bor du i hus eller lejlighed?");

        boliggruppe = new ToggleGroup();
        
        hus = new RadioButton("Hus");
        hus.setToggleGroup(boliggruppe);
        hus.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        lejlighed = new RadioButton("Lejlighed");
        lejlighed.setToggleGroup(boliggruppe);  
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("Bor du i lejlighed skal du være opmærksom på, at "
                + "du ikke nødvendigvis kan oplade en elbil\npå din bopæl. Undersøg "
                + "derfor gerne, om der er ladestandere nær din adresse.");
        faktaboks.setId("faktaboks-label");
        
        faktaVbox = new VBox(faktaboks);
        faktaVbox.getStyleClass().add("vbox-fakta");
        
        centerGrid = new GridPane();

        centerGrid = new GridPane();
        
        centerGrid.add(spørgsmål, 0, 0, 1, 2);
        centerGrid.add(hus, 1, 0);
        centerGrid.add(lejlighed, 1, 1);   
        centerGrid.add(fejlbesked, 1, 2);
        centerGrid.add(faktaVbox, 0, 3, 3, 1);        
        
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));

        for (int i = 0; i < 4; i++) {
            if (i < 3) {
                RowConstraints row = new RowConstraints(50);
                centerGrid.getRowConstraints().add(row);
            } else {
                RowConstraints row = new RowConstraints(210);
                centerGrid.getRowConstraints().add(row);
            }
        }

        centerGrid.setId("centergrid");

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
             TestSide2 testside2 = new TestSide2(elbilBase, brugerBase, bruger);
             getScene().setRoot(testside2);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if ((hus.isSelected() || lejlighed.isSelected())) {
                
                // Ryd først indexet i arraylisten med besvarelser:
                if( bruger.getBehov().getBesvarelser().size() == 3 ) {
                bruger.getBehov().getBesvarelser().remove(2);
                }              
                
                Besvarelse besvarelse = new Besvarelse("spørgsmål 3");
                
                // Sæt scorerne efter det valgte svar:
                if(hus.isSelected()) {
                    besvarelse.setSpørgsmålSvar( hus.getText() );
                    besvarelse.tilføjTilScore(100, 0, 0, 0, 0);
                    besvarelse.setSvar_uddybning("Eftersom du bor i hus, bør du "
                            + "kunne få installeret en ladeboks på din bopæl. En "
                            + "ladeboks gør opladningen hurtigere, men også mere "
                            + "sikker. Oplader du blot en elbil via stikkontakten, "
                            + "så risikerer du at overbelaste din boligs "
                            + "elinstallationer. Vil du vide, hvor der er "
                            + "ladestandere, kan du klikke på kortet til højre.");
                } else if(lejlighed.isSelected()) {
                    besvarelse.setSpørgsmålSvar( lejlighed.getText() );
                    besvarelse.tilføjTilScore(50, 0, 0, 0, 0);
                    besvarelse.setSvar_uddybning("Du har angivet, at du bor i "
                            + "lejlighed. Ved de fleste lejligheder kan det ikke "
                            + "lade sig gøre at lade en elbil op. Vær derfor "
                            + "opmærksom på, om der er mulighed for dette. "
                            + "Hvis ikke, så bør du undersøge, om der er "
                            + "ladestandere nær din bopæl, hvilket du kan gøre "
                            + "ved at klikke på kortet til højre. ");
                }
                
                bruger.getBehov().tilføjBesvarelse(besvarelse, 2);  
                
                // *TEST* om brugeren har fået de rigtige score:
                System.out.println("SPØRGSMÅL 3:");
                System.out.println("Antal besvarelser i array: " + bruger.getBehov().getBesvarelser().size());                
                bruger.getBehov().udprintAlleScore( bruger.getFornavn() );
                    

                TestSide4 testside4 = new TestSide4(elbilBase, brugerBase, bruger);
                getScene().setRoot(testside4);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
