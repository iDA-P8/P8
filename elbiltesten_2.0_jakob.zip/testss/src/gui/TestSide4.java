/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * ANTAL PERSONER
 *
 * @author jakobbakhummelgaard
 */
public class TestSide4 extends BorderPane {

    Label overskrift, underoverskrift, progress, spørgsmål, fejlbesked,
            faktaboks;

    RadioButton to, fire, fem, overFem;
    ToggleGroup gruppe;

    Button tilbage, næste;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox, faktaVbox;

    public TestSide4(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Elbiltesten");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om dine krav til bilens størrelse");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.58);
        progressbar.setId("progressbar");
        
        progress = new Label("58%", progressbar);
        
        topBox = new VBox(overskrift, underoverskrift, progress);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Hvor mange personer skal bilen\nkunne transportere?");

        gruppe = new ToggleGroup();
        
        to = new RadioButton("1-2 personer");
        to.setToggleGroup(gruppe);
        to.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        fire = new RadioButton("2-4 personer");
        fire.setToggleGroup(gruppe);  
        
        fem = new RadioButton("4-5 personer");
        fem.setToggleGroup(gruppe);  

        overFem = new RadioButton("Flere end 5");
        overFem.setToggleGroup(gruppe);          
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("Elbiler kommer i mange størrelser. Du kan få "
                + "alt fra den lille bybil til den store stationcar - det er "
                + "kun budgettet, der sætter grænser."); 
        faktaboks.setId("faktaboks-label");
        
        faktaVbox = new VBox(faktaboks);
        faktaVbox.getStyleClass().add("vbox-fakta");
        
        centerGrid = new GridPane();

        centerGrid = new GridPane();
        centerGrid.add(spørgsmål, 0, 0, 1, 4);
        centerGrid.add(to, 1, 0);
        centerGrid.add(fire, 1, 1);
        centerGrid.add(fem, 1, 2);
        centerGrid.add(overFem, 1, 3);     
        centerGrid.add(fejlbesked, 1, 4);
        centerGrid.add(faktaVbox, 0, 5, 3, 1);

        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));

        for (int i = 0; i < 6; i++) {
            if (i < 5) {
                RowConstraints row = new RowConstraints(50);
                centerGrid.getRowConstraints().add(row);
            } else {
                RowConstraints row = new RowConstraints(110);
                centerGrid.getRowConstraints().add(row);
            }
        }

        centerGrid.setId("centergrid");

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide3 testside3 = new TestSide3(elbilBase, brugerBase, bruger);
            getScene().setRoot(testside3);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if (to.isSelected() || fire.isSelected() 
                    || fem .isSelected() || overFem.isSelected()) {
                
                // Sæt antal_passagerer til at være det valgte svar:
                if(to.isSelected()) {
                    bruger.getBehov().setAntal_passagerer( to.getText() );
                } else if(fire.isSelected()) {
                    bruger.getBehov().setAntal_passagerer( fire.getText() );
                } else if(fem.isSelected()) {
                    bruger.getBehov().setAntal_passagerer( fem.getText() );
                } else if(overFem.isSelected()) {
                    bruger.getBehov().setAntal_passagerer( overFem.getText() );
                }
                System.out.println(bruger.getFornavn() + " har brug for en elbil, som kan transportere " 
                         + bruger.getBehov().getAntal_passagerer());
                
                TestSide5 testside5 = new TestSide5(elbilBase, brugerBase, bruger);
                getScene().setRoot(testside5);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
