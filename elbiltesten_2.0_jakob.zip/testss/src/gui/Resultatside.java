/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.geometry.NodeOrientation;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/** 
 *
 * @author jakobbakhummelgaard
 */
public class Resultatside extends BorderPane {

    Label overskrift, rubrik, skalaoverskrift, skalarubrik, biloverskrift, bilrubrik, 
            dagligKørselOverskrift, dagligKørselIntro, dagligKørselUddybning1, 
            dagligKørselUddybning2, point0, point50, point100, bilensStørrelseOverskrift,
            bilensStørrelseIntro, bilensStørrelseUddybning, øvrigeForholdOverskrift, 
            øvrigeForholdIntro,øvrigeForholdUddybning;

    Label bilnavn, årgang, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde;

    Label kol1, kol2, kol3, ræk1, ræk2, ræk3, ræk4, celB1, celB2, celB3, celC1,
            celC2, celD2, celD3;

    Rectangle skala, baggrundGridpane;

    Image blad_billede, brændstof_billede, elbil_billede, spørgsmålstegn_billede;

    ImageView blad, brændstof, elbil_match, spørgsmålstegn1, spørgsmålstegn2;

    Button button;
    VBox resultat, bilForklaringBox, bil, bilbillede, dagligKørselBox, 
            bilensStørrelseBox, øvrigeForholdBox;

    TableView kmTable;
    TableColumn kolonne1, kolonne2, kolonne3, kolonne4;

    GridPane topGrid, bilGrid, kmGrid;

    Pane skalaPane, brændstofPane, bladPane;
    StackPane skalaStack;

    Tab dagligKørselTab, bilensStørrelseTab, øvrigeForholdTab;
    TabPane tabpane;

    BorderPane dagligKørselBorderPane;

    public Resultatside(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        // model
        bruger.getBehov().udregnScore();
            System.out.println(bruger.getFornavn() + "'s score er: " + bruger.getBehov().getScore() + " ud af 100");
        bruger.getBehov().matchElbil(elbilBase);
            System.out.println(bruger.getFornavn() + " anbefaler vi en " + bruger.getBehov().getElbil().getMærke() +" "+ bruger.getBehov().getElbil().getModel() + " til");
        
        
        // TOPPEN AF BORDERPANE
        
        // Del 1: Overordnet resultatboks
        overskrift = new Label("Dit resultat:\n"+ bruger.getBehov().getScore()+"/100");
        overskrift.setId("overskrift-label");

        rubrik = new Label("Når du har scoret "+ bruger.getBehov().getScore()+" point betyder det, at en elbil passer rigtig godt til dig og dine behov.\n" // gør dynamisk
                + "Læs dine specifikke resultater nederst og bliv klogere på hvor godt en elbil passer til dig.");
        rubrik.setId("forklaring-label");

        resultat = new VBox(overskrift, rubrik);
        resultat.setId("vbox-resultat");
        
        // Del 2: Pointskala
        skalaoverskrift = new Label("Pointskala");
        skalaoverskrift.setId("skala-overskrift");
        
        skalarubrik = new Label("Pointskalaen viser hvor godt en elbil passer til dig på en skala fra 0 til 100.");
        skalarubrik.setId("skala-forklaring");

        skala = new Rectangle(400, 25);
        skala.setId("linear-gradient");
        
        skalaPane = new Pane(skala);
        skalaPane.setId("skala-pane");

        point0 = new Label("0");
        point0.setId("point0-label");

        point50 = new Label("50");
        point50.setId("point50-label");

        point100 = new Label("100");
        point100.setId("point100-label");

        blad_billede = new Image(getClass().getResourceAsStream("/billeder/blad-ikon.png"));
        blad = new ImageView(blad_billede);
        blad.setFitWidth(35);
        blad.setPreserveRatio(true);
        blad.setSmooth(true);
        blad.setCache(true);

        brændstof_billede = new Image(getClass().getResourceAsStream("/billeder/braendstof-ikon.png"));
        brændstof = new ImageView(brændstof_billede);
        brændstof.setFitWidth(25);
        brændstof.setPreserveRatio(true);
        brændstof.setSmooth(true);
        brændstof.setCache(true);

        bladPane = new Pane(blad);
        bladPane.setId("blad-pane");
        bladPane.setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);

        brændstofPane = new Pane(brændstof);
        brændstofPane.setId("braendstof-pane");

        skalaStack = new StackPane(skalaoverskrift, skalaPane, point0, point50, point100, brændstofPane, bladPane, skalarubrik);
        skalaStack.getStylesheets().add("/css/resultat-skala.css");

        // Del 3: Forslag til elbil
        biloverskrift = new Label("Bedste elbil til dig");
        biloverskrift.setId("overskrift-label");

        bilrubrik = new Label("På baggrund af dine svar i testen anbefaler vi en "
                + bruger.getBehov().getElbil().getMærke() +" "+ bruger.getBehov().getElbil().getModel() 
                + " som det bedste bilkøb til dig, hvis du vælger at købe en elbil.");      
        bilrubrik.setId("rubrik-label");

        elbil_billede = new Image(getClass().getResourceAsStream( bruger.getBehov().getElbil().getBillede_url() ));
        elbil_match = new ImageView(elbil_billede);
        elbil_match.setFitHeight(150);
        elbil_match.setPreserveRatio(true);
        elbil_match.setSmooth(true);
        elbil_match.setCache(true);

        bilnavn = new Label( bruger.getBehov().getElbil().getMærke() +" "+ bruger.getBehov().getElbil().getModel() );
        bilnavn.setId("bilnavn-label");

        pris = new Label("Fra kr. " + bruger.getBehov().getElbil().getPris() );
        pris.setId("pris-label");

        sæder = new Label("Antal sæder: " + bruger.getBehov().getElbil().getSæder() );
        sæder.setId("bilinfo-label");
        
        rækkevidde = new Label("Rækkevidde: " + bruger.getBehov().getElbil().getRækkevidde() + " km");
        rækkevidde.setId("bilinfo-label");        

        ladetidHjemme = new Label("Ladetid hjemme: " + bruger.getBehov().getElbil().getLadetid_hjemme() );
        ladetidHjemme.setId("bilinfo-label");

        ladetidUde = new Label("Ladetid ude: " + bruger.getBehov().getElbil().getLadetid_ude() );
        ladetidUde.setId("bilinfo-label");

        bil = new VBox(bilnavn, pris, sæder, rækkevidde, ladetidHjemme, ladetidUde);
        bil.getStyleClass().add("vbox");

        bilbillede = new VBox(elbil_match);
        bilbillede.setId("bilbillede-vbox");


        bilGrid = new GridPane();
        bilGrid.setId("bilgrid");

        bilGrid.add(bilbillede, 0, 1);
        bilGrid.add(bil, 1, 1);
        
        
        bilForklaringBox = new VBox(biloverskrift, bilGrid, bilrubrik);
        bilForklaringBox.setId("vbox-bil-resultat");  

        // Tilføj Del 1, 2 og 3 til toppen af borderpane via en gridpane      
        topGrid = new GridPane();

        topGrid.add(resultat, 0, 0);
        topGrid.add(skalaStack, 0, 1);
        topGrid.add(bilForklaringBox, 1, 0, 1, 2);

        topGrid.getColumnConstraints().add(new ColumnConstraints(617));
        topGrid.getColumnConstraints().add(new ColumnConstraints(618));

        topGrid.getRowConstraints().add(new RowConstraints(165));
        topGrid.getRowConstraints().add(new RowConstraints(165));

        topGrid.setId("topgrid");

        setTop(topGrid);

        //TABPANE
        dagligKørselBorderPane = new BorderPane();

        // TAB 1: DAGLIG KØRSEL
        dagligKørselOverskrift = new Label("Daglig Kørsel");
        dagligKørselOverskrift.setId("overskrift-label");
        
        dagligKørselIntro = new Label("Dine daglige kørselsmønstre er ideelle for en " // gør dynamisk
                + "elbils rækkevidde, fordi du ikke kører flere km, end hvad der er "
                + "muligt for en elbil. En elbil vil derfor ikke kræve, at du ændrer "
                + "på dine daglige rutiner.");
        dagligKørselUddybning1 = new Label("Vi har anbefalet en VW e-Up! som den mest " // gør dynamisk
                + "passende elbil til dine behov. En VW e-Up! har en rækkevidde på op "
                + "til 280 km, hvor du kan forvente en reel rækkevidde 180 km.");
        dagligKørselUddybning2 = new Label("Eftersom du bor i lejlighed bør du " // gør dynamisk
                + "undersøge dine muligheder for at kunne lade en elbil op, da det ikke "
                + "er sikkert, at du kan lade en elbil op lige ved din bopæl.");

        dagligKørselBox = new VBox(dagligKørselOverskrift, dagligKørselIntro, dagligKørselUddybning1, dagligKørselUddybning2);
        dagligKørselBox.setId("vbox-tekst-tabs");


        // KM TABEL
        spørgsmålstegn_billede = new Image(getClass().getResourceAsStream("/billeder/info-black.png"));
        spørgsmålstegn1 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn1.setFitWidth(16);
        spørgsmålstegn1.setPreserveRatio(true);
        spørgsmålstegn1.setSmooth(true);
        spørgsmålstegn1.setCache(true);

        spørgsmålstegn2 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn2.setFitWidth(15);
        spørgsmålstegn2.setPreserveRatio(true);
        spørgsmålstegn2.setSmooth(true);
        spørgsmålstegn2.setCache(true);

        kol1 = new Label("Du kører");
        kol1.setId("kolonner");

        kol2 = new Label("Bilens rækkevidde");
        kol2.setId("kolonner");

        ræk1 = new Label("Daglig kørsel");
        ræk1.setId("raekke-titler");
        
        ræk2 = new Label("Rækkevidde tilovers ved daglig kørsel");

        celB1 = new Label( bruger.getBehov().getDaglig_kørsel() + " km");
        celB1.setId("celler-almindelige");

        celC1 = new Label( bruger.getBehov().getElbil().getRækkevidde() + " km", spørgsmålstegn1);
        celC1.setId("totaler");

                // udregn rækkevidde tilovers ved daglig kørsel ift. bilens rækkevidde
        int kmTilovers = bruger.getBehov().getElbil().getRækkevidde() - (bruger.getBehov().getDaglig_kørsel()) ;
        celC2 = new Label(kmTilovers + " km");
        celC2.setId("totaler-uden-kant");
        
        
        celD2 = new Label("reel total", spørgsmålstegn2);
        celD2.setId("totaler");

        // udregn rækkevidde tilovers ved daglig kørsel ift. bilens REELLE rækkevidde
        celD3 = new Label("!! km");
        celD3.setId("totaler-uden-kant");
        
        baggrundGridpane = new Rectangle(450, 50, Color.LIGHTGREY);

        kmGrid = new GridPane();
        kmGrid.add(baggrundGridpane, 0, 2, 3, 1);
        kmGrid.add(kol1, 1, 0);
        kmGrid.add(kol2, 2, 0);
        kmGrid.add(ræk1, 0, 1);
        kmGrid.add(ræk2, 0, 2);
        kmGrid.add(celB1, 1, 1);
        kmGrid.add(celC1, 2, 1);
        kmGrid.add(celC2, 2, 2);

        kmGrid.getColumnConstraints().add(new ColumnConstraints(170));
        kmGrid.getColumnConstraints().add(new ColumnConstraints(140));
        kmGrid.getColumnConstraints().add(new ColumnConstraints(140));
        kmGrid.getColumnConstraints().add(new ColumnConstraints(140));

        kmGrid.getStylesheets().add("/css/resultat_tabel.css");
        kmGrid.getStyleClass().add("grid");
        
        dagligKørselTab = new Tab("Daglig kørsel");
        dagligKørselTab.setContent(dagligKørselBorderPane);
        dagligKørselBorderPane.setId("borderpane-daglig-koersel");

        dagligKørselBorderPane.setLeft(dagligKørselBox);
        dagligKørselBorderPane.setRight(kmGrid);
        
        // BILENS STØRRELSE TAB
        bilensStørrelseOverskrift = new Label("Bilens Størrelse");
        bilensStørrelseOverskrift.setId("overskrift-label");
        
        bilensStørrelseIntro = new Label("Elbiler kommer i forskellige størrelser. "
                + "Vi har anbefalet en VW e-Up!, fordi du har markeret, at bilen "
                + "skal bruges som den sekundære bil, og fordi det kun er op til "
                + "4 personer, som skal kunne sidde i den.");
        
        bilensStørrelseUddybning = new Label("Derudover må en VW e-Up! ikke få "
                + "monteret anhængertræk. Du er dog ikke afhængig af, at din bil "
                + "er udstyret med anhængertræk.");        
        
        bilensStørrelseBox = new VBox(bilensStørrelseOverskrift, bilensStørrelseIntro, bilensStørrelseUddybning);
        bilensStørrelseBox.setId("vbox-tekst-tabs");
        
        bilensStørrelseTab = new Tab("Bilens størrelse");
        bilensStørrelseTab.setContent(bilensStørrelseBox);
        
        
        // ØVRIGE FORHOLD TAB
        øvrigeForholdOverskrift = new Label("Øvrige Forhold");
        øvrigeForholdOverskrift.setId("overskrift-label");
        
        øvrigeForholdIntro = new Label("Du har markeret, at du i høj grad er en "
                + "systematisk person. Dette er vigtigt for en elbilsejer at være, "
                + "da det til tider kræver planlægning at eje en elbil. Skal du "
                + "f.eks. køre en længere tur end bilens rækkevidde tillader, så "
                + "bør du have planlagt mulige opladningssteder langs din rute.");
        
        øvrigeForholdUddybning = new Label("1-4 gange om året kører du længere ture "
                + "end 600 km. Du skal her være opmærksom på, at det vil en "
                + "VW-e-Up! ikke kunne klare på én opladning.");        
        
        øvrigeForholdBox = new VBox(øvrigeForholdOverskrift, øvrigeForholdIntro, øvrigeForholdUddybning);
        øvrigeForholdBox.setId("vbox-tekst-tabs");
        
        øvrigeForholdTab = new Tab("Øvrige forhold");
        øvrigeForholdTab.setContent(øvrigeForholdBox);
        
        tabpane = new TabPane(dagligKørselTab, bilensStørrelseTab, øvrigeForholdTab);
        tabpane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        this.getStylesheets().add("/css/resultatside.css");


        setCenter(tabpane);

    }

}


//
//
//
//// KM TABEL
//        spørgsmålstegn_billede = new Image(getClass().getResourceAsStream("/billeder/info-black.png"));
//        spørgsmålstegn1 = new ImageView(spørgsmålstegn_billede);
//        spørgsmålstegn1.setFitWidth(16);
//        spørgsmålstegn1.setPreserveRatio(true);
//        spørgsmålstegn1.setSmooth(true);
//        spørgsmålstegn1.setCache(true);
//
//        spørgsmålstegn2 = new ImageView(spørgsmålstegn_billede);
//        spørgsmålstegn2.setFitWidth(15);
//        spørgsmålstegn2.setPreserveRatio(true);
//        spørgsmålstegn2.setSmooth(true);
//        spørgsmålstegn2.setCache(true);
//
//        kol1 = new Label("Du kører");
//        kol1.setId("kolonner");
//
//        kol2 = new Label("Bilens rækkevidde");
//        kol2.setId("kolonner");
//
//        kol3 = new Label("Bilens reelle rækkevidde");
//        kol3.setId("kolonner");
//
//        ræk1 = new Label("Fast daglig kørsel");
//        ræk1.setId("raekke-titler");
//
//        ræk2 = new Label("Øvrig daglig kørsel");
//        ræk2.setId("raekke-titler");
//
//        ræk3 = new Label("Total");
//        
//        ræk4 = new Label("Rækkevidde tilovers ved daglig kørsel");
//
//        celB1 = new Label( bruger.getBehov().getDaglig_kørsel() + " km");
//        celB1.setId("celler-almindelige");
//
//        celB2 = new Label( 0 + " km");
//        celB2.setId("celler-almindelige");
//
//        celB3 = new Label((bruger.getBehov().getDaglig_kørsel()) + " km");
//        celB3.setId("totaler");
//
//        celC3 = new Label( bruger.getBehov().getElbil().getRækkevidde() + " km", spørgsmålstegn1);
//        celC3.setId("totaler");
//
//                // udregn rækkevidde tilovers ved daglig kørsel ift. bilens rækkevidde
//        int kmTilovers = bruger.getBehov().getElbil().getRækkevidde() - (bruger.getBehov().getDaglig_kørsel()) ;
//        celC4 = new Label(kmTilovers + " km");
//        celC4.setId("totaler-uden-kant");
//        
//        
//        celD3 = new Label("reel total", spørgsmålstegn2);
//        celD3.setId("totaler");
//
//        // udregn rækkevidde tilovers ved daglig kørsel ift. bilens REELLE rækkevidde
//        celD4 = new Label("!! km");
//        celD4.setId("totaler-uden-kant");
//        
//        baggrundGridpane = new Rectangle(590, 50, Color.LIGHTGREY);
//
//        kmGrid = new GridPane();
//        kmGrid.add(baggrundGridpane, 0, 4, 4, 1);
//        kmGrid.add(kol1, 1, 0);
//        kmGrid.add(kol2, 2, 0);
//        kmGrid.add(kol3, 3, 0);
//        kmGrid.add(ræk1, 0, 1);
//        kmGrid.add(ræk2, 0, 2);
//        kmGrid.add(ræk3, 0, 3);
//        kmGrid.add(ræk4, 0, 4);
//        kmGrid.add(celB1, 1, 1);
//        kmGrid.add(celB2, 1, 2);
//        kmGrid.add(celB3, 1, 3);
//        kmGrid.add(celC3, 2, 3);
//        kmGrid.add(celC4, 2, 4);
//        kmGrid.add(celD3, 3, 3);
//        kmGrid.add(celD4, 3, 4);
//
//        kmGrid.getColumnConstraints().add(new ColumnConstraints(170));
//        kmGrid.getColumnConstraints().add(new ColumnConstraints(140));
//        kmGrid.getColumnConstraints().add(new ColumnConstraints(140));
//        kmGrid.getColumnConstraints().add(new ColumnConstraints(140));
//
//        kmGrid.getStylesheets().add("/css/resultat_tabel.css");
//        kmGrid.getStyleClass().add("grid");
//        
//        dagligKørselTab = new Tab("Daglig kørsel");
//        dagligKørselTab.setContent(dagligKørselBorderPane);
//        dagligKørselBorderPane.setId("borderpane-daglig-koersel");
//
//        dagligKørselBorderPane.setLeft(dagligKørselBox);
//        dagligKørselBorderPane.setRight(kmGrid);














//        elbil_billede = new Image(getClass().getResourceAsStream("/billeder/vw_eup.jpg"));
//        elbil_match = new ImageView(elbil_billede);
//        elbil_match.setFitWidth(225);
//        elbil_match.setPreserveRatio(true);
//        elbil_match.setSmooth(true);
//        elbil_match.setCache(true);
//
//        bilnavn = new Label("Volkswagen e-Up!");
//        bilnavn.setId("bilnavn-label");
//
//        pris = new Label("Fra kr. 162.994");
//        pris.setId("pris-label");
//
//        rækkevidde = new Label("Rækkevidde: 258 km");
//        rækkevidde.setId("bilinfo-label");
//
//        sæder = new Label("Antal sæder: 4");
//        sæder.setId("bilinfo-label");      
//
//        ladetidHjemme = new Label("Ladetid hjemme: Ca. 5 timer");
//        ladetidHjemme.setId("bilinfo-label");   
//
//        ladetidUde = new Label("Ladetid ude: 60 minutter");
//        ladetidUde.setId("bilinfo-label");
//
//        bil = new VBox(elbil_match, bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde);
//        bil.getStyleClass().add("vbox");
