/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author alexa
 */
public class BrugerBase {
    
    private ArrayList<Bruger> brugerBase;
    
    public BrugerBase() {
        brugerBase = new ArrayList();
    }
    
    public void tilføjBruger(Bruger bruger) {
        brugerBase.add(bruger);
    }
    
    
    public int findBruger(String email, String kodeord) throws BrugerIkkeFundetException {
        // Find bruger ved email og kodeord i basen
        for(Bruger bru : brugerBase) {
            if(bru.getEmail().equals(email) &&  bru.getKodeord().equals(kodeord)) {
                int i = brugerBase.indexOf(bru);
                return i;
            }
        }
        throw new BrugerIkkeFundetException( "Brugeren med email: " + email + " blev ikke fundet." );
    }
    
    
    public boolean erOprettet(String email, String kodeord) {
        // Find bruger ved email og kodeord i basen

        try {
            findBruger(email, kodeord);
            return true;
        } catch (BrugerIkkeFundetException e) {
            return false;
        }
    }
    
    
    public Bruger hentBruger(String email, String kodeord) {
        // Find brugeren
        try {
            int index = findBruger(email, kodeord); // finder indexet for brugeren
            Bruger bruger = brugerBase.get(index); // henter brugeren
            return bruger; 
        } catch (BrugerIkkeFundetException e) {
            // hvis brugeren ikke blev fundet
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    
    
    
    
}

