/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author alexa
 */
public class Behov {

    private int daglig_kørsel; // TestSide1
    private String længere_end_500; // TestSide2
    private String bopæl_type; // TestSide3
    private String antal_passagerer; // TestSide4
    private String anhængertræk; // TestSide5
    private String struktureret_person; // TestSide6

    private int score;
    private Elbil elbil;

    public Behov() {

    }

    public int getDaglig_kørsel() {
        return daglig_kørsel;
    }

    public void setDaglig_kørsel(int fast_kørsel) {
        this.daglig_kørsel = fast_kørsel;
    }

    public String getLængere_end_500() {
        return længere_end_500;
    }

    public void setLængere_end_500(String længere_end_500) {
        this.længere_end_500 = længere_end_500;
    }

    public String getBopæl_type() {
        return bopæl_type;
    }

    public void setBopæl_type(String bopæl_type) {
        this.bopæl_type = bopæl_type;
    }

    public String getAntal_passagerer() {
        return antal_passagerer;
    }

    public void setAntal_passagerer(String antal_passagerer) {
        this.antal_passagerer = antal_passagerer;
    }

    public String getStruktureret_person() {
        return struktureret_person;
    }

    public void setStruktureret_person(String struktureret_person) {
        this.struktureret_person = struktureret_person;
    }

    public String getAnhængertræk() {
        return anhængertræk;
    }

    public void setAnhængertræk(String anhængertræk) {
        this.anhængertræk = anhængertræk;
    }

    public int getScore() {
        return score;
    }

    public void addToScore(int i) {
        this.score = score + i;
    }

    public void udregnScore() {

        // *TEST*
        this.score = this.score / 4;

        // sæt vægtning for hvert enkelt behov
        // hvad med svarmulighederne?
    }

    public void matchElbil(ArrayList<Elbil> elbilsbase) {

        // inddrag de relevante behov (jeg tænker sæder og rækkevidde):
        String antal_passagerer = this.antal_passagerer;

        // gennemgå listen med elbiler og find det bedste match udfra:
        // rækkevidde?
        this.elbil = elbilsbase.get(2);
    }

    public Elbil getElbil() {
        return elbil;
    }

}
