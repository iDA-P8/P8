/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Besvarelse;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * ANHÆNGERTRÆK
 *
 * @author jakobbakhummelgaard
 */
public class TestSide5 extends BorderPane {

    Label overskrift, underoverskrift, progress, spørgsmål, fejlbesked,
            faktaboks;

    RadioButton skal, kan, nej;
    ToggleGroup gruppe;

    Button tilbage, næste;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox, faktaVbox;

    public TestSide5(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Elbiltesten");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om dit behov i forhold til anhængertræk");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.725);
        progressbar.setId("progressbar");
        
        progress = new Label("72%", progressbar);
        
        topBox = new VBox(overskrift, underoverskrift, progress);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Har du behov for at have\nanhængertræk på din bil?");

        gruppe = new ToggleGroup();
        
        skal = new RadioButton("Skal have");
        skal.setToggleGroup(gruppe);
        skal.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        kan = new RadioButton("At foretrække, men kan undvære");
        kan.setToggleGroup(gruppe);  
        
        nej = new RadioButton("Behøver ikke");
        nej.setToggleGroup(gruppe);      
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("At have mange kg på anhængertrækket er ikke en af "
                + "fordelene ved at eje en elbil. Elbiler under 400.000 kr. er p.t. "
                + "ikke godkendte til at trække særlig meget vægt."); 
        faktaboks.setId("faktaboks-label");
        
        faktaVbox = new VBox(faktaboks);
        faktaVbox.getStyleClass().add("vbox-fakta");
        
        centerGrid = new GridPane();

        centerGrid = new GridPane();
        centerGrid.add(spørgsmål, 0, 0, 1, 3);
        centerGrid.add(skal, 1, 0);
        centerGrid.add(kan, 1, 1);
        centerGrid.add(nej, 1, 2);
        centerGrid.add(fejlbesked, 1, 3);
        centerGrid.add(faktaVbox, 0, 4, 3, 1);

        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));

        for (int i = 0; i < 5; i++) {
            if (i < 4) {
                RowConstraints row = new RowConstraints(50);
                centerGrid.getRowConstraints().add(row);
            } else {
                RowConstraints row = new RowConstraints(160);
                centerGrid.getRowConstraints().add(row);
            }
        }

        centerGrid.setId("centergrid");

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide4 testside4 = new TestSide4(elbilBase, brugerBase, bruger);
            getScene().setRoot(testside4);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if (skal.isSelected() || kan.isSelected() 
                    || nej.isSelected()) {
                
                // Ryd først indexet i arraylisten med besvarelser:
                if( bruger.getBehov().getBesvarelser().size() == 5 ) {
                bruger.getBehov().getBesvarelser().remove(4);
                }                      
                
                Besvarelse besvarelse = new Besvarelse("spørgsmål 5");
                
                // Sæt behov for anhængertræk til at være det valgte svar:
                if(skal.isSelected()) {
                    besvarelse.setSpørgsmålSvar( skal.getText() );
                    besvarelse.tilføjTilScore(0, -500, -500, 0, 0);
                    besvarelse.setSvar_uddybning("Fordi du har angivet, at din "
                            + "bil skal have anhængertræk, udelukkes en VW e-UP! "
                            + "og Peugeot e-208, da disse to elbiler ifølge "
                            + "dansk lovgivning ikke er godkendt til at have "
                            + "monteret anhængertræk.");
                } else if(kan.isSelected()) {
                    besvarelse.setSpørgsmålSvar( kan.getText() );
                    besvarelse.tilføjTilScore(0, 0, 0, 25, 25);
                    besvarelse.setSvar_uddybning("Du har angivet, at du fortrækker, "
                            + "men kan undvære, at din bil har monteret anhængertræk. "
                            + "Biler som VW e-UP! og Peugeot e-208 er ifølge dansk "
                            + "lovgivning ikke er godkendt til at have monteret "
                            + "anhængertræk. Dette er noget, du bør være opmærksom "
                            + "på, hvis du vælger at købe en af disse elbiler.");
                } else if(nej.isSelected()) {
                    besvarelse.setSpørgsmålSvar( nej.getText() );
                    besvarelse.tilføjTilScore(0, 0, 0, 0, 0);
                    besvarelse.setSvar_uddybning(" ");
                }

                bruger.getBehov().tilføjBesvarelse(besvarelse, 4);  
                
                // *TEST* om brugeren har fået de rigtige score:
                System.out.println("SPØRGSMÅL 5:");
                System.out.println("Antal besvarelser i array: " + bruger.getBehov().getBesvarelser().size());                
                bruger.getBehov().udprintAlleScore( bruger.getFornavn() );
                
                
                TestSide6 testside6 = new TestSide6(elbilBase, brugerBase, bruger);
                getScene().setRoot(testside6);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
