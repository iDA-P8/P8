/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Besvarelse;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * LÆNGERE TURE END 500 KM
 *
 * @author jakobbakhummelgaard
 */
public class TestSide2 extends BorderPane {

    Label overskrift, underoverskrift, progress, spørgsmål, fejlbesked,
            faktaboks;

    RadioButton aldrig, kvartal, måned, ofte;
    ToggleGroup gruppe;

    Button tilbage, næste;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox, faktaVbox;

    public TestSide2(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Elbiltesten");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os mere om dit kørselsmønster");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.29);
        progressbar.setId("progressbar");
        
        progress = new Label("29%", progressbar);
        
        topBox = new VBox(overskrift, underoverskrift, progress);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Hvor ofte kører du længere ture\nend 500 km?");

        gruppe = new ToggleGroup();
        
        aldrig = new RadioButton("Aldrig");
        aldrig.setToggleGroup(gruppe);
        aldrig.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        kvartal = new RadioButton("1-4 gange om året");
        kvartal.setToggleGroup(gruppe);  
        
        måned = new RadioButton("1 gang om måneden");
        måned.setToggleGroup(gruppe);  

        ofte = new RadioButton("Flere gange om måneden");
        ofte.setToggleGroup(gruppe);          
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("I takt med at ny teknologi til elbiler bliver udviklet"
                + ", kan nye elbiler køre længere og længere. Tesla er det bilmærke, "
                + "som producerer elbiler med den længste rækkevidde, og deres "
                + "største modeller kan køre omkring 500 kilometer på en opladning.");
        faktaboks.setId("faktaboks-label");
        
        faktaVbox = new VBox(faktaboks);
        faktaVbox.getStyleClass().add("vbox-fakta");

        centerGrid = new GridPane();

        centerGrid = new GridPane();
        centerGrid.add(spørgsmål, 0, 0, 1, 4);
        centerGrid.add(aldrig, 1, 0);
        centerGrid.add(kvartal, 1, 1);
        centerGrid.add(måned, 1, 2);
        centerGrid.add(ofte, 1, 3);     
        centerGrid.add(fejlbesked, 1, 4);
        centerGrid.add(faktaVbox, 0, 5, 3, 1);
        
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        
        for (int i = 0; i < 6; i++) {
            if (i < 5) {
                RowConstraints row = new RowConstraints(50);
                centerGrid.getRowConstraints().add(row);
            } else {
                RowConstraints row = new RowConstraints(110);
                centerGrid.getRowConstraints().add(row);
            }
        }
                               
        centerGrid.setId("centergrid");

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide1 testside1 = new TestSide1(elbilBase, brugerBase, bruger);
            getScene().setRoot(testside1);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if (aldrig.isSelected() || kvartal.isSelected() 
                    || måned .isSelected() || ofte.isSelected()) {
                
                // Ryd først indexet i arraylisten med besvarelser:
                if( bruger.getBehov().getBesvarelser().size() == 2 ) {
                bruger.getBehov().getBesvarelser().remove(1);
                }
                
                
                Besvarelse besvarelse = new Besvarelse("spørgsmål 2");
                
                // Sæt scorerne efter det valgte svar:
if(aldrig.isSelected()) {
                    besvarelse.setSpørgsmålSvar( aldrig.getText() );
                    besvarelse.tilføjTilScore(100, 0, 0, 0, 0);
                    besvarelse.setSvar_uddybning("De fleste elbiler har, på "
                            + "nuværende tidspunkt, en rækkevidde, på en enkelt "
                            + "opladning, på under 500 kilometer. Du har angivet, "
                            + "at du aldrig kører over 500 kilometer og er derfor "
                            + "nødvendigvis ikke nødsaget til at oplade din elbil, "
                            + "mens du er på farten.");
                } else if(kvartal.isSelected()) {
                    besvarelse.setSpørgsmålSvar( kvartal.getText() );
                    besvarelse.tilføjTilScore(75, 20, 30, 0, 10);
                    besvarelse.setSvar_uddybning("De fleste elbiler har, på "
                            + "nuværende tidspunkt, en rækkevidde, på en enkelt "
                            + "opladning, på under 500 kilometer. Da du 1 til 4 "
                            + "gange årligt kører over 500 kilometer, vil du "
                            + "under alle omstændigheder være nødsaget til at "
                            + "oplade din elbil på disse ture. Fordi det ikke "
                            + "sker ofte, vurderes det ikke at være til gene at "
                            + "have en elbil med kort rækkevidde.");
                } else if(måned.isSelected()) {
                    besvarelse.setSpørgsmålSvar( måned.getText() );
                    besvarelse.tilføjTilScore(50, 0, 10, 20, 30);
                    besvarelse.setSvar_uddybning("De fleste elbiler har, på "
                            + "nuværende tidspunkt, en rækkevidde, på en enkelt "
                            + "opladning, på under 500 kilometer. Da du 1 gang "
                            + "månedligt kører over 500 kilometer, vil du under "
                            + "alle omstændigheder være nødsaget til at oplade "
                            + "din elbil på disse ture. Det kan være en fordel "
                            + "at vælge en elbil med en lang rækkevidde, da det "
                            + "kan betyde, at du kun skal oplade din elbil én "
                            + "gang i stedet for 2 eller 3 gange.");
                } else if(ofte.isSelected()) {
                    besvarelse.setSpørgsmålSvar( ofte.getText() );
                    besvarelse.tilføjTilScore(25, 0, 0, 30, 20);
                    besvarelse.setSvar_uddybning("De fleste elbiler har, på "
                            + "nuværende tidspunkt, en rækkevidde, på en enkelt "
                            + "opladning, på under 500 kilometer. Da du flere "
                            + "gange om måneden kører over 500 kilometer, vil "
                            + "du under alle omstændigheder være nødsaget til "
                            + "at oplade din elbil på disse ture. Det kan stadig "
                            + "være en fordel at vælge en elbil med en lang "
                            + "rækkevidde, da det kan betyde, at du kun skal "
                            + "oplade din elbil én gang i stedet for 2 eller 3 gange.");
                }
                
                bruger.getBehov().tilføjBesvarelse(besvarelse, 1); 
                
                // *TEST* om brugeren har fået de rigtige score:
                System.out.println("SPØRGSMÅL 2:");
                System.out.println("Antal besvarelser i array: " + bruger.getBehov().getBesvarelser().size());
                bruger.getBehov().udprintAlleScore( bruger.getFornavn() );
                    
               
                TestSide3 testside3 = new TestSide3(elbilBase, brugerBase, bruger);
                getScene().setRoot(testside3);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
