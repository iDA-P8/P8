/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elbilstesten;

import gui.Forside;
import gui.RedigerBruger;
import gui.Resultatside;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import model.Besvarelse;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Elbilstesten extends Application {

    Font academySansBold45 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 45);
    Font academySans24 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 24);
    Font academySansLightItalic18 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-LightItalic.ttf"), 18);
    Font academySansLight18 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Light.ttf"), 18);
    Font academySansDemiBold16 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-DemiBold.ttf"), 16);

    ArrayList<Elbil> elbilBase;
    BrugerBase brugerBase = new BrugerBase();
    
    @Override
    public void start(Stage primaryStage) throws Exception {

        
        // DB connection:
        String url = "jdbc:mysql://127.0.0.1:3306/elbilstesten?useTimezone=true&serverTimezone=UTC";
        String username = "root";
        String password = "";

        Connection dbCon = null;
        Statement stmt = null;
        ResultSet rs = null;

        System.out.println("Connecting database...");

try {
    
    // getting database Connection to MySQL server
    dbCon = DriverManager.getConnection(url, username, password);
    // getting PreparedStatement to execute query
    stmt = dbCon.createStatement();
    
    // HENT ALLE ELBILER FRA DATABASEN OG TILFØJ TIL ARRAYLISTEN AF ELBILER:
    String table = "elbil";
    elbilBase = new ArrayList<>();
        
    // ResultSet returned by query
    rs = stmt.executeQuery("SELECT * FROM " + table); // executeQuery method for getting data from a table

    // As long as there is a next row, do the following:
    while( rs.next() ) {
        // Opret elbils-objekterne til systemet ud fra elbilerne i databasen:
        Elbil elbil = new Elbil(rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),
                                    rs.getInt(6), rs.getString(7), rs.getString(8));
                elbilBase.add(elbil); 
    }
    
    // tilføj billeder af bilerne:
    elbilBase.get(0).setBillede_url("/billeder/vw_eup.jpg");
    elbilBase.get(1).setBillede_url("/billeder/peugeot_e208.jpg");
    elbilBase.get(2).setBillede_url("/billeder/tesla_model3.jpg");
    elbilBase.get(3).setBillede_url("/billeder/audi_etron.jpg");

    
    // BRUGERBASE:
    
    
                // ResultSet returned by query
            rs = stmt.executeQuery("SELECT b.first_name, b.last_name, b.email, b.kodeord, b.kørsel_behov,\n" +
"(SELECT længere_end_500_km FROM længere_end_500_km l WHERE l.idLængere_end_500_km = b.idLængere_end_500_km) længere,\n" +
"(SELECT bopæl_type FROM bopæl bo WHERE bo.idBopæl = b.idBopæl_behov) bopæl,\n" +
"(SELECT antal_passagerer FROM antal_passagerer ap WHERE ap.idAntal_passagerer = b.idAntal_passagerer_behov) antal_passagerer,\n" +
"(SELECT anhængertræk_afhængig FROM anhængertræk anh WHERE anh.idAnhængertræk = b.idAnhængertræk_behov) anhængertræk,\n" +
"(SELECT struktureret_person FROM struktureret_person sp WHERE sp.idStruktureret_person = b.idStruktureret_person_behov) struktureret_person,\n" +
"b.idElbil_match,\n" +
"b.score, vw_scoreSamlet, peugeot_scoreSamlet, tesla_scoreSamlet, audi_scoreSamlet\n" +
"FROM bruger b"); // executeQuery method for getting data from a table

            // As long as there is a next row, do the following:
            while( rs.next() ) {
                // Opret brugerne i brugerbasen ud fra databasens data:
                Bruger bruger = new Bruger(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
                    // hent brugerens behov fra de andre tabeller
                    Besvarelse dagligKørsel = new Besvarelse("spørgsmål 1", rs.getInt(5));
                            bruger.getBehov().tilføjBesvarelse(dagligKørsel, 0);
                    Besvarelse længere_end_500 = new Besvarelse("spørgsmål 2");
                        længere_end_500.setSpørgsmålSvar(rs.getString(6));
                            bruger.getBehov().tilføjBesvarelse(længere_end_500, 1);
                    Besvarelse bopæl = new Besvarelse("spørgsmål 3");
                        bopæl.setSpørgsmålSvar(rs.getString(7));
                            bruger.getBehov().tilføjBesvarelse(bopæl, 2);
                    Besvarelse antal_passagerer = new Besvarelse("spørgsmål 4");
                        antal_passagerer.setSpørgsmålSvar(rs.getString(8));
                            bruger.getBehov().tilføjBesvarelse(antal_passagerer, 3);
                    Besvarelse anhængertræk = new Besvarelse("spørgsmål 5");
                        anhængertræk.setSpørgsmålSvar(rs.getString(9));
                            bruger.getBehov().tilføjBesvarelse(anhængertræk, 4);
                    Besvarelse struktureret_person = new Besvarelse("spørgsmål 6");
                        struktureret_person.setSpørgsmålSvar(rs.getString(10));
                            bruger.getBehov().tilføjBesvarelse(struktureret_person, 5);
                            
                    // hent og sæt de sidste værdier som er elbil og score:
                    bruger.getBehov().setElbil( elbilBase.get( rs.getInt(11)-1 ) );
                    bruger.getBehov().setScore(rs.getInt(12));
                    bruger.getBehov().setVw_scoreSamlet(rs.getInt(13));
                    bruger.getBehov().setPeugeot_scoreSamlet(rs.getInt(14));
                    bruger.getBehov().setTesla_scoreSamlet(rs.getInt(15));
                    bruger.getBehov().setAudi_scoreSamlet(rs.getInt(16));
                    
                    bruger.setTestUdført(true);
                    
                    brugerBase.getBrugerBase().add(bruger);
            }
    
    dbCon.close();
} catch (SQLException e) {
    throw new IllegalStateException("Cannot connect the database!", e);
}
        
            
        Forside forside = new Forside(elbilBase, brugerBase, null);
//        Forside1 forside1 = new Forside1();
//        LoginSide login = new LoginSide(brugerbase);
          RedigerBruger rb = new RedigerBruger();
//        TestSide1 testside1 = new TestSide1();
//        TestSide2 testside2 = new TestSide2();
//        TestSide6 testside6 = new TestSide6();
//        Resultatside resultat = new Resultatside(elbilBase, brugerBase, null);

        Scene scene = new Scene(forside, 1280, 720);

        primaryStage.setTitle("Elbilstesten");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String args[]) {
        launch(args);
    }
}
