/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author alexa
 */
public class Behov {

    private int score;
    private Elbil elbil;
    
    private int vw_scoreSamlet;
    private int peugeot_scoreSamlet;
    private int tesla_scoreSamlet;
    private int audi_scoreSamlet;
    // En brugers behovklasse har en array variabel, der indeholder besvarelserne på de seks spørgsmål i testen:
    private ArrayList<Besvarelse> besvarelser;

    public Behov() {
        besvarelser = new ArrayList<>();
    }

    public void tilføjBesvarelse(Besvarelse besvarelse, int index) {
        this.besvarelser.add(index, besvarelse);
    }

    public ArrayList<Besvarelse> getBesvarelser() {
        return besvarelser;
    }

    public void udregnScore() {
        for (Besvarelse besvarelse : besvarelser) {
            this.score = this.score + besvarelse.getScore();
        }

        // Tag den samlede score fra alle besvarelser(spørgsmål 1, 2, 3 og 6) og divider med fire:
        this.score = this.score / 4;
    }

    public int getScore() {
        return score;
    }

    public void matchElbil(ArrayList<Elbil> elbilbase) {
        // Akkumuler alle scorer fra de fire elbiler og find den med den højeste:
        vw_scoreSamlet = 0;
        peugeot_scoreSamlet = 0;
        tesla_scoreSamlet = 0;
        audi_scoreSamlet = 0;

        for (Besvarelse besvarelse : besvarelser) {
            vw_scoreSamlet = vw_scoreSamlet + besvarelse.getVW_score();
            peugeot_scoreSamlet = peugeot_scoreSamlet + besvarelse.getPeugeot_score();
            tesla_scoreSamlet = tesla_scoreSamlet + besvarelse.getTesla_score();
            audi_scoreSamlet = audi_scoreSamlet + besvarelse.getAudi_score();
        }

        int max = vw_scoreSamlet;
        this.elbil = elbilbase.get(0);

        if (peugeot_scoreSamlet > max) {
            max = peugeot_scoreSamlet;
            this.elbil = elbilbase.get(1);
        }
        if (tesla_scoreSamlet > max) {
            max = tesla_scoreSamlet;
            this.elbil = elbilbase.get(2);
        }
        if (audi_scoreSamlet > max) {
            max = audi_scoreSamlet;
            this.elbil = elbilbase.get(3);
        }

    }

    public Elbil getElbil() {
        return elbil;
    }

    public int getVw_scoreSamlet() {
        return vw_scoreSamlet;
    }

    public int getPeugeot_scoreSamlet() {
        return peugeot_scoreSamlet;
    }

    public int getTesla_scoreSamlet() {
        return tesla_scoreSamlet;
    }

    public int getAudi_scoreSamlet() {
        return audi_scoreSamlet;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setElbil(Elbil elbil) {
        this.elbil = elbil;
    }

    public void setVw_scoreSamlet(int vw_scoreSamlet) {
        this.vw_scoreSamlet = vw_scoreSamlet;
    }

    public void setPeugeot_scoreSamlet(int peugeot_scoreSamlet) {
        this.peugeot_scoreSamlet = peugeot_scoreSamlet;
    }

    public void setTesla_scoreSamlet(int tesla_scoreSamlet) {
        this.tesla_scoreSamlet = tesla_scoreSamlet;
    }

    public void setAudi_scoreSamlet(int audi_scoreSamlet) {
        this.audi_scoreSamlet = audi_scoreSamlet;
    }
    
    
    public void nyTest() {
        besvarelser.clear();
        this.score = 0;
        this.vw_scoreSamlet = 0;
        this.peugeot_scoreSamlet = 0;
        this.tesla_scoreSamlet = 0;
        this.audi_scoreSamlet = 0;
    }
    

    // SLET INDEN AFLEVERING
    public void udprintAlleScore(String navn) {

        int scoreSamlet = 0;
        int vw_scoreSamlet = 0;
        int peugeot_scoreSamlet = 0;
        int tesla_scoreSamlet = 0;
        int audi_scoreSamlet = 0;

        for (Besvarelse besvarelse : besvarelser) {
            scoreSamlet = scoreSamlet + besvarelse.getScore();
            vw_scoreSamlet = vw_scoreSamlet + besvarelse.getVW_score();
            peugeot_scoreSamlet = peugeot_scoreSamlet + besvarelse.getPeugeot_score();
            tesla_scoreSamlet = tesla_scoreSamlet + besvarelse.getTesla_score();
            audi_scoreSamlet = audi_scoreSamlet + besvarelse.getAudi_score();
        }

        System.out.println(navn + " har en samlet score på: " + scoreSamlet);
        System.out.println(navn + " har en samlet vw_score på: " + vw_scoreSamlet);
        System.out.println(navn + " har en samlet peugeoet_score på: " + peugeot_scoreSamlet);
        System.out.println(navn + " har en samlet tesla_score på: " + tesla_scoreSamlet);
        System.out.println(navn + " har en samlet audi_score på: " + audi_scoreSamlet);

    }

}
