/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author alexa
 */
public class Besvarelse {
    
    
    private String spørgsmål_nr;
    private String svar_hvis_string;
    private int svar_hvis_int;
    
    private int score;
    
    private int vw_score;
    private int peugeot_score;
    private int tesla_score;
    private int audi_score;
 
    private String svar_uddybning;
    
 
    public Besvarelse(String spørgsmål_nr) {
        this.spørgsmål_nr = spørgsmål_nr;
    }
    public void setSpørgsmålSvar(String svar_hvis_string) {
        this.svar_hvis_string = svar_hvis_string;
    }
    
    public Besvarelse(String spørgsmål_nr, int svar_hvis_int) {
        this.spørgsmål_nr = spørgsmål_nr;
        this.svar_hvis_int = svar_hvis_int;
    }

    // hvis svaret er af typen string:
    public void tilføjTilScore(int score, int vw_score, int peugeot_score, int tesla_score, int audi_score) {
        this.score = score;
        this.vw_score = vw_score;
        this.peugeot_score = peugeot_score;
        this.tesla_score = tesla_score;
        this.audi_score = audi_score;
    }
    
    public int getScore() {
        return this.score;
    }
    
    public int getVW_score() {
        return this.vw_score;
    }
    public int getPeugeot_score() {
        return this.peugeot_score;
    }
    public int getTesla_score() {
        return this.tesla_score;
    }
    public int getAudi_score() {
        return this.audi_score;
    }
    
    public int getSvar_hvis_int() {
        return this.svar_hvis_int;
    }
    public String getSvar_hvis_string() {
        return this.svar_hvis_string;
    }
 
    public String getSvar_uddybning() {
        return this.svar_uddybning;
    }
    public void setSvar_uddybning(String svar_uddybning) {
        this.svar_uddybning = svar_uddybning;
    }

    public void setSvar_hvis_string(String svar_hvis_string) {
        this.svar_hvis_string = svar_hvis_string;
    }

    public void setSvar_hvis_int(int svar_hvis_int) {
        this.svar_hvis_int = svar_hvis_int;
    }


    
}
