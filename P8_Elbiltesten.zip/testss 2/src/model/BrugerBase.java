/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author alexa
 */
public class BrugerBase {
    
    private ArrayList<Bruger> brugerBase;
    
    public BrugerBase() {
        brugerBase = new ArrayList();

        
//        // HENT ALLE BRUGERPROFILER FRA DATABASEN OG TILFØJ TIL ARRAYLISTEN AF BRUGERE:
//    
//            // DB connection:
//            String url = "jdbc:mysql://127.0.0.1:3306/elbilstesten?useTimezone=true&serverTimezone=UTC";
//            String username = "root";
//            String password = "";
//
//            Connection dbCon = null;
//            Statement stmt = null;
//            ResultSet rs = null;
//
//            System.out.println("Connecting database...");
//
//        try {
//            
//            // getting database Connection to MySQL server
//            dbCon = DriverManager.getConnection(url, username, password);
//            // getting PreparedStatement to execute query
//            stmt = dbCon.createStatement();            
//    
//            // ResultSet returned by query
//            rs = stmt.executeQuery("SELECT b.first_name, b.last_name, b.email, b.kodeord, b.kørsel_behov,\n" +
//"(SELECT længere_end_500_km FROM længere_end_500_km l WHERE l.idLængere_end_500_km = b.idLængere_end_500_km) længere,\n" +
//"(SELECT bopæl_type FROM bopæl bo WHERE bo.idBopæl = b.idBopæl_behov) bopæl,\n" +
//"(SELECT antal_passagerer FROM antal_passagerer ap WHERE ap.idAntal_passagerer = b.idAntal_passagerer_behov) antal_passagerer,\n" +
//"(SELECT anhængertræk_afhængig FROM anhængertræk anh WHERE anh.idAnhængertræk = b.idAnhængertræk_behov) anhængertræk,\n" +
//"(SELECT struktureret_person FROM struktureret_person sp WHERE sp.idStruktureret_person = b.idStruktureret_person_behov) struktureret_person,\n" +
//"(SELECT model FROM elbil e WHERE e.idElbil = b.idElbil_match) elbil,\n" +
//"b.score, vw_scoreSamlet, peugeot_scoreSamlet, tesla_scoreSamlet, audi_scoreSamlet\n" +
//"FROM bruger b"); // executeQuery method for getting data from a table
//
//            // As long as there is a next row, do the following:
//            while( rs.next() ) {
//                // Opret brugerne i brugerbasen ud fra databasens data:
//                Bruger bruger = new Bruger(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
//                    // hent brugerens behov fra de andre tabeller
//                    Besvarelse dagligKørsel = new Besvarelse("spørgsmål 1", rs.getInt(5));
//                            bruger.getBehov().tilføjBesvarelse(dagligKørsel, 0);
//                    Besvarelse længere_end_500 = new Besvarelse("spørgsmål 2");
//                        længere_end_500.setSpørgsmålSvar(rs.getString(6));
//                            bruger.getBehov().tilføjBesvarelse(længere_end_500, 1);
//                    Besvarelse bopæl = new Besvarelse("spørgsmål 3");
//                        bopæl.setSpørgsmålSvar(rs.getString(7));
//                            bruger.getBehov().tilføjBesvarelse(bopæl, 2);
//                    Besvarelse antal_passagerer = new Besvarelse("spørgsmål 4");
//                        antal_passagerer.setSpørgsmålSvar(rs.getString(8));
//                            bruger.getBehov().tilføjBesvarelse(antal_passagerer, 3);
//                    Besvarelse anhængertræk = new Besvarelse("spørgsmål 5");
//                        anhængertræk.setSpørgsmålSvar(rs.getString(9));
//                            bruger.getBehov().tilføjBesvarelse(anhængertræk, 4);
//                    Besvarelse struktureret_person = new Besvarelse("spørgsmål 6");
//                        struktureret_person.setSpørgsmålSvar(rs.getString(10));
//                            bruger.getBehov().tilføjBesvarelse(struktureret_person, 5);
//                            
//                    // hent og sæt de sidste værdier som er elbil og score:
//                    bruger.getBehov().setScore(rs.getInt(12));
//                    bruger.getBehov().setVw_scoreSamlet(rs.getInt(13));
//                    bruger.getBehov().setPeugeot_scoreSamlet(rs.getInt(14));
//                    bruger.getBehov().setTesla_scoreSamlet(rs.getInt(15));
//                    bruger.getBehov().setAudi_scoreSamlet(rs.getInt(16));
//                    
//                    brugerBase.add(bruger);
//                    System.out.println("Bruger fra DB: " + bruger.getFornavn() + " " + bruger.getEfternavn() + " " + bruger.getEmail() + " " + bruger.getKodeord() );
//            }
//        
//            dbCon.close();
//        } catch (SQLException e) {
//            throw new IllegalStateException("Cannot connect the database!", e);
//        }  
    
    }
    
    public void tilføjBruger(Bruger bruger) {
        
        // DB connection:
        String url = "jdbc:mysql://127.0.0.1:3306/elbilstesten?useTimezone=true&serverTimezone=UTC";
        String username = "root";
        String password = "";

        Connection dbCon = null;
       
        try {
            
            // getting database Connection to MySQL server
            dbCon = DriverManager.getConnection(url, username, password);

            String txtSQL = "INSERT INTO bruger (first_name, last_name, email, kodeord) "
                    + "VALUES(?, ?, ?, ?)";
            // Execute insert query
            PreparedStatement preparedStmt = dbCon.prepareStatement(txtSQL);
            preparedStmt.setString(1, bruger.getFornavn());
            preparedStmt.setString(2, bruger.getEfternavn());
            preparedStmt.setString(3, bruger.getEmail());
            preparedStmt.setString(4, bruger.getKodeord());
            
            preparedStmt.execute();
            
            dbCon.close();
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }        
        
        brugerBase.add(bruger);
    }
    
    
    public int findBruger(String email, String kodeord) throws BrugerIkkeFundetException {
        // Find bruger ved email og kodeord i basen
        for(Bruger bru : brugerBase) {
            if(bru.getEmail().equals(email) &&  bru.getKodeord().equals(kodeord)) {
                int i = brugerBase.indexOf(bru);
                return i;
            }
        }
        throw new BrugerIkkeFundetException( "Brugeren med email: " + email + " blev ikke fundet." );
    }
    
    
    public boolean erOprettet(String email, String kodeord) {
        // Find bruger ved email og kodeord i basen

        try {
            findBruger(email, kodeord);
            return true;
        } catch (BrugerIkkeFundetException e) {
            return false;
        }
    }
    
    
    public Bruger hentBruger(String email, String kodeord) {
        // Find brugeren
        try {
            int index = findBruger(email, kodeord); // finder indexet for brugeren
            Bruger bruger = brugerBase.get(index); // henter brugeren
            return bruger; 
        } catch (BrugerIkkeFundetException e) {
            // hvis brugeren ikke blev fundet
            System.err.println(e.getMessage());
            return null;
        }
    }
    
    public ArrayList<Bruger> getBrugerBase() {
        return brugerBase;
    }
    
    
    
    
    
}

