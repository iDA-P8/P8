/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 *
 * HUS ELLER LEJLIGHED
 * 
 * @author jakobbakhummelgaard
 */
public class TestSide2 extends BorderPane {
    
    Label overskrift, underoverskrift, spørgsmål, fejlbesked;

    RadioButton hus, lejlighed, primær, sekundær;
    ToggleGroup boliggruppe, bilgruppe;

    Button tilbage, næste;
    
    ProgressBar progressbar;
    GridPane centerGrid;
    
    HBox knapper;
    VBox topBox;

    Font academySansBold45 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 45);
    Font academySans24 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 24);
    
    Font academySansLight18 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Light.ttf"), 18);
    Font academySansDemiBold16 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-DemiBold.ttf"), 16);    
    
    public TestSide2() {
        
    final BooleanProperty firstTime = new SimpleBooleanProperty(true);
    
        // Top of borderpane
        overskrift = new Label("Spørgsmål 2");
        overskrift.setFont(academySansBold45);
        
        underoverskrift = new Label("Fortæl os om din boligsituation");
        underoverskrift.setFont(academySans24);

        
        topBox = new VBox(overskrift, underoverskrift);
        topBox.setPadding(new Insets(12));
        topBox.setSpacing(12);
        topBox.setMaxWidth(800);
        topBox.setAlignment(Pos.CENTER);
        topBox.setStyle("-fx-background-color: white;");
        
        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Bor du i hus eller lejlighed?");
        spørgsmål.setFont(academySansLight18);
        spørgsmål.setPadding(new Insets(12));
              
        boliggruppe = new ToggleGroup();
        
        hus = new RadioButton("Hus");
        hus.setFont(academySansLight18);
        hus.setToggleGroup(boliggruppe);
        hus.setAlignment(Pos.CENTER_RIGHT);
        hus.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        lejlighed = new RadioButton("Lejlighed");
        lejlighed.setFont(academySansLight18);
        lejlighed.setToggleGroup(boliggruppe);  
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setFont(academySansLight18);
        fejlbesked.setTextFill(Color.RED);
        fejlbesked.setVisible(false);
        
        centerGrid = new GridPane();
        centerGrid.add(spørgsmål, 0, 0, 1, 2);
        centerGrid.add(hus, 1, 0);
        centerGrid.add(lejlighed, 1, 1);
        centerGrid.add(fejlbesked, 1, 2);
        
        centerGrid.setPadding(new Insets(30));
        centerGrid.setVgap(30);
        centerGrid.setMaxWidth(800);
        centerGrid.setStyle("-fx-background-color: white;");
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        
        BorderPane.setMargin(centerGrid, new Insets(8, 0, 8, 0));
        
        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setFont(academySansDemiBold16);
        tilbage.setPrefSize(125, 60);
        tilbage.setStyle("-fx-background-color: grey; -fx-text-fill: white;"); 
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide1 testside1 = new TestSide1();
            getScene().setRoot(testside1);
    });
     
        næste = new Button("Næste");
        næste.setFont(academySansDemiBold16);
        næste.setPrefSize(125, 60);
        næste.setStyle("-fx-background-color: rgb(0, 30, 80); -fx-text-fill: white;");
        næste.setOnAction((ActionEvent event) -> {
            if (hus.isSelected() || lejlighed.isSelected()) {
                System.out.println("udført rigtigt");
            } else {
                fejlbesked.setVisible(true);
                //TestSide2 testside2 = new TestSide2();
                //getScene().setRoot(testside2);
            }
        });
        
        knapper = new HBox(tilbage, næste);
        knapper.setAlignment(Pos.CENTER_RIGHT);
        knapper.setPadding(new Insets(12));
        knapper.setSpacing(20);
        knapper.setMaxWidth(800);
        knapper.setStyle("-fx-background-color: white;");
        
        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        setBottom(knapper);
       // this.setStyle("-fx-background-color: lightgrey;");
    }
}
