/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elbilstesten;

import gui.Forside;
import gui.LoginSide;
import gui.Opladning;
import gui.OpretBruger;
import gui.Resultatside;
import gui.TestSide1;
import testDesigns.Forside1;
import testDesigns.TestSide;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.geometry.Rectangle2D;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import model.BrugerBase;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Elbilstesten extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        BrugerBase brugerBase = new BrugerBase();
        
        Forside forside = new Forside();
        LoginSide login = new LoginSide(brugerBase);
        TestSide1 testside1 = new TestSide1();
        Opladning opladning = new Opladning();
        Resultatside resultat = new Resultatside();
        

        Scene scene = new Scene(login, 1280, 720);
        
        primaryStage.setTitle("Elbilsten");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String args[]) {
        launch(args);
    }
}
