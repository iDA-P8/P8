package gui;

import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Forside extends BorderPane {
    

    Label overskrift, underoverskrift, systembeskrivelse, testbeskrivelse, bilbeskrivelse;
            
//    bilnavn, pris, rækkevidde, sæder,
//            ladetidHjemme, ladetidUde, 

    Image vw_eup_billede, nissan_leaf_billede, hyundai_ioniq_billede, tesla_model3_billede, spørgsmålstegn_billede;

    ImageView vw_eup, nissan_leaf, hyundai_ioniq, tesla_model3, spørgsmålstegn1, spørgsmålstegn2;

    Button start;
    
    Tooltip tooltip1;
    Tooltip tooltip2;
    Dialog dialog;

    VBox menulinje, bil1, bil2, bil3, bil4, bundBox;

    GridPane topGrid, centerGrid, bottomGrid;

    Font academySansBold45 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 45);
    Font academySansBold30 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 30);
    Font academySansBold24 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 24);
    Font academySansDemiBold20 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-DemiBold.ttf"), 20);
    Font academySans24 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 24);
    Font academySans16 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 16);
    Font academySans15 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 15);

    /** Elementer til logo
     * 
     */
    Rectangle rectangle, line;
    Label systemNavn, madeBy;
    Image ikon_billede;
    ImageView ikon;
    StackPane stack;
    

    public Forside(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {
        

        // LOGO
        rectangle = new Rectangle(200, 90, Color.web("#66BD63"));
        line = new Rectangle(175, 2, Color.rgb(255, 255, 255));

        systemNavn = new Label("Elbiltesten");
        systemNavn.setFont(academySansBold30);
        systemNavn.setStyle("-fx-text-fill: white;");

        madeBy = new Label("Fra IDAs drenge");
        madeBy.setFont(academySans15);
        madeBy.setStyle("-fx-text-fill: white;");

        ikon_billede = new Image(getClass().getResourceAsStream("/billeder/ikon.png"));
        ikon = new ImageView(ikon_billede);
        ikon.setFitWidth(25);
        ikon.setFitHeight(43);
        ikon.setPreserveRatio(true);
        ikon.setSmooth(true);
        ikon.setCache(true);

        stack = new StackPane();
        stack.getChildren().addAll(rectangle, ikon, systemNavn, line, madeBy);
        stack.setAlignment(Pos.TOP_LEFT);

        StackPane.setMargin(rectangle, new Insets(0, 0, 0, 50));
        StackPane.setMargin(ikon, new Insets(10, 0, 0, 65));
        StackPane.setMargin(systemNavn, new Insets(10, 0, 0, 95));
        StackPane.setMargin(line, new Insets(55, 0, 0, 62));
        StackPane.setMargin(madeBy, new Insets(61, 0, 0, 100));

        // TOPPEN AF BORDERPANE
        /**
         * Tilføj VBox'en menulinje til setTop hvis vi ønsker at have en
         * overskrift med underoverksrift.
         */
        overskrift = new Label("Elbilguiden");
        overskrift.setFont(academySansBold45);
        //overskrift.setStyle("-fx-text-fill: white;");
        //overskrift.setTextFill(Color.rgb(54, 128, 45)); 

        underoverskrift = new Label("Elbilguiden fortæller dig kort og præcist, "
                + "om et skifte til elbil ville\nfungere for dig og opfylde dine behov");
        underoverskrift.setFont(academySans24);

        //menulinje = new VBox(overskrift, underoverskrift);
        //menulinje.setAlignment(Pos.CENTER);
        //menulinje.setSpacing(10);
        //menulinje.setStyle("-fx-background-color: #001E50;"); 

//        Hvis vi vil have en linje under overskriften
// 
//        topGrid = new GridPane();
//        topGrid.add(overskrift,0,0);
//        topGrid.setAlignment(Pos.CENTER);
//        topGrid.setPadding(new Insets(12));
//        topGrid.setVgap(12);
//        topGrid.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80), 
//            Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
//            BorderStrokeStyle.NONE, BorderStrokeStyle.NONE, 
//            BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
//            CornerRadii.EMPTY, new BorderWidths(1), Insets.EMPTY)));
        setTop(stack);

        
        
        // CENTER AF BORDERPANE
        bilbeskrivelse = new Label("Eksempler på elbiler");
        bilbeskrivelse.setFont(academySansBold24);
        
        systembeskrivelse = new Label("Elbilguiden fortæller dig kort og præcist, "
                + "om et skifte til elbil ville\nfungere for dig og opfylde dine behov");
        systembeskrivelse.setFont(academySans24);

        centerGrid = new GridPane();
        centerGrid.add(bilbeskrivelse, 0, 0);
        
        // Bilkort:
        int kortPlacering = 0;
        for( Elbil elbil : elbilBase ) {
            
            // hent alle attributter til kortene
            String billede_url = elbil.getBillede_url();
            String mærke = elbil.getMærke();
            String model = elbil.getModel();
            int årgang = elbil.getÅrgang();
            int pris = elbil.getPris();
            int sæder = elbil.getSæder();
            int rækkevidde = elbil.getRækkevidde();
            String ladetid_hjemme = elbil.getLadetid_hjemme();
            String ladetid_ude = elbil.getLadetid_ude();
            
            // kald bilKort metoden og sæt værdierne efter attributterne:
            VBox vb = new VBox( bilKort(billede_url, mærke, model, årgang, pris, sæder, rækkevidde, ladetid_hjemme, ladetid_ude) );
            
            // placer bilkortet som det næste i rækken på centerGrid:
            centerGrid.add(vb, kortPlacering, 1);
            kortPlacering = kortPlacering + 1;
        }

        centerGrid.setAlignment(Pos.CENTER);
        setCenter(centerGrid);
        

        // BUNDEN AF BORDERPANE
        testbeskrivelse = new Label("Find ud af om en elbil er det rette for dig");
        testbeskrivelse.setFont(academySansDemiBold20);

        start = new Button("Start elbiltesten");
        start.setFont(academySansDemiBold20);
        start.setPrefHeight(60);
        start.setPrefWidth(200);
        start.setStyle("-fx-background-color: rgb(75, 169, 80); -fx-text-fill: white;");
        start.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                // vi skal finde ud af hvilken bruger, som er logget ind og medgive denne til konstruktoren for testside objektet:
                // *TEST* for nu bruger vi bare det første objekt vi instantierede ude i main
                Bruger bruger = brugerBase.hentBruger("testBruger1@test.dk", "password1");
                
                TestSide1 testside1 = new TestSide1(elbilBase, brugerBase, bruger);
                getScene().setRoot(testside1);
            }
        });

        bundBox = new VBox(testbeskrivelse, start);
        bundBox.setAlignment(Pos.CENTER);
        bundBox.setPadding(new Insets(12));
        bundBox.setSpacing(12);

        setBottom(bundBox);

        this.setStyle("-fx-background-color: white;");
    }
    
//    public void dialogOmLadetidUde(String header) {   
//        Alert ladetidUdeInfo = new Alert(Alert.AlertType.INFORMATION);
//            ladetidUdeInfo.setTitle("Ladetid ude");
//            ladetidUdeInfo.setContentText("Dette afhænger af mange faktorer.\n-Tilbageværende strøm på batteriet\n-Vekselstrøm / jævnstrøm");
//            ladetidUdeInfo.setHeaderText(header);
//            ladetidUdeInfo.showAndWait();
//    }
    
    
        public VBox bilKort(String img_url, String mærke, String model, int årgang, int pris, int sæder,
                 int rækkevidde, String ladetid_hjemme, String ladetid_ude) {
              
        Image billede = new Image(getClass().getResourceAsStream(img_url));
        ImageView bil_view = new ImageView(billede);
        bil_view.setFitWidth(225);
        bil_view.setPreserveRatio(true);
        bil_view.setSmooth(true);
        bil_view.setCache(true);

        Label bil_navn = new Label( mærke + " " + model );
        bil_navn.setFont(academySansBold24);
        
        Label bil_år = new Label( "Årgang: " + Integer.toString(årgang));
        bil_år.setFont(academySans16);

        Label bil_pris;
        bil_pris = new Label( "Fra kr. " + Integer.toString(pris));
        bil_pris.setFont(academySans16);
        
        Label bil_sæder = new Label("Antal sæder: " + Integer.toString(sæder));
        bil_sæder.setFont(academySans15); 
        
        Label bil_rækkevidde = new Label("Rækkevidde: " + Integer.toString(rækkevidde) + " km");
        bil_rækkevidde.setFont(academySans15);

        // tooltip:
        spørgsmålstegn_billede = new Image(getClass().getResourceAsStream("/billeder/info-black.png"));
        spørgsmålstegn1 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn1.setFitWidth(16);
        spørgsmålstegn1.setPreserveRatio(true);
        spørgsmålstegn1.setSmooth(true);
        spørgsmålstegn1.setCache(true);
        
        spørgsmålstegn_billede = new Image(getClass().getResourceAsStream("/billeder/info-black.png"));
        spørgsmålstegn2 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn2.setFitWidth(16);
        spørgsmålstegn2.setPreserveRatio(true);
        spørgsmålstegn2.setSmooth(true);
        spørgsmålstegn2.setCache(true);
        
        Label bil_ladetidHjemme = new Label("Ladetid hjemme: " + ladetid_hjemme, spørgsmålstegn1);
        bil_ladetidHjemme.setContentDisplay(ContentDisplay.RIGHT);
        bil_ladetidHjemme.setFont(academySans15);

        Label bil_ladetidUde = new Label("Ladetid ude: " + ladetid_ude, spørgsmålstegn2);
        bil_ladetidUde.setContentDisplay(ContentDisplay.RIGHT);
        bil_ladetidUde.setFont(academySans15);
        
        tooltip1 = new Tooltip("Ved alm. strøm");
        bil_ladetidUde.setTooltip(tooltip1);
        bil_ladetidHjemme.setTooltip(tooltip1);
        // tooltip slut

        VBox bilKort = new VBox(  bil_view, bil_navn, bil_år, bil_pris, bil_sæder, bil_rækkevidde, bil_ladetidHjemme, bil_ladetidUde);
        VBox.setMargin(bil_navn, new Insets(10, 10, 0, 10));
        VBox.setMargin(bil_år, new Insets(10, 10, 0, 10));
        VBox.setMargin(bil_pris, new Insets(0, 10, 10, 10));
        VBox.setMargin(bil_sæder, new Insets(10, 10, 0, 10));
        VBox.setMargin(bil_rækkevidde, new Insets(0, 10, 0, 10));
        VBox.setMargin(bil_ladetidHjemme, new Insets(0, 10, 0, 10));
        VBox.setMargin(bil_ladetidUde, new Insets(0, 10, 0, 10));

        bilKort.setStyle("-fx-border-color: #001E50; -fx-border-insets: 10, 10, 10, 10; -fx-border-width: 2");
        bilKort.setPrefSize(225, 300);
            
            return bilKort;
        }
    
    
    
    
}


        