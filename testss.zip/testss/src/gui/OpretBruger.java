/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import model.Bruger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * @author jakobbakhummelgaard
 */
public class OpretBruger extends BorderPane {
    
    Label overskrift, oplysninger, fornavn, efternavn, email, kodeord;
    
    TextField fornavnFelt, efternavnFelt, emailFelt;
    
    PasswordField kodeordFelt;
    
    Button opretKnap;
    
    GridPane grid;
    
    Bruger loggetInd;
    
    
    public Bruger display(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {
        this.loggetInd = bruger;
        
        Stage window = new Stage();
        window.setTitle("Opret bruger");
        
        overskrift = new Label("Opret bruger");
        oplysninger = new Label("Indtast dine oplysninger");
        
        fornavn = new Label("Fornavn");
        efternavn = new Label("Efternavn");
        email = new Label("Email");
        kodeord = new Label("Kodeord");
        
        fornavnFelt = new TextField();
        efternavnFelt = new TextField();       
        emailFelt = new TextField();    
        kodeordFelt = new PasswordField();
        
        opretKnap = new Button("Opret bruger");
        opretKnap.setOnAction((ActionEvent event) -> {
            loggetInd = new Bruger(fornavnFelt.getText(), efternavnFelt.getText(), emailFelt.getText(), kodeordFelt.getText());
            brugerBase.tilføjBruger(loggetInd);
            window.close(); 
        });
        
        grid = new GridPane();
        
        grid.add(overskrift, 0, 0);
        grid.add(oplysninger, 0, 1);
        
        grid.add(fornavn, 0, 2);
        grid.add(fornavnFelt, 0, 3);
        
        grid.add(efternavn, 1, 2);
        grid.add(efternavnFelt, 1, 3);
        
        grid.add(email, 0, 4);
        grid.add(emailFelt, 0, 5);     
        
        grid.add(kodeord, 1, 4);
        grid.add(kodeordFelt, 1, 5);     
        
        grid.add(opretKnap, 0, 6);
        
        Scene scene = new Scene(grid, 640, 360);
        window.setScene(scene);
        window.showAndWait();
        
    return loggetInd;   
    }
    
}


