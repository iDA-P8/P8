/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * DAGLIG KØRSEL
 *
 * @author jakobbakhummelgaard
 */
public class TestSide1 extends BorderPane {

    Label overskrift, underoverskrift, spørgsmål1, spørgsmål2, km1, km2, fejlbesked,
            faktaboks;
    
    TextField fastKørsel, øvrigKørsel;

    Button tilbage, næste;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox;

    public TestSide1(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        System.out.println("Brugerens navn vi har med i testen er: " + bruger.getFornavn() + bruger.getEfternavn());
        
        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Spørgsmål 1");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om dine daglige kørselsmønstre");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.125);
        progressbar.setId("progressbar");

        topBox = new VBox(overskrift, underoverskrift, progressbar);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål1 = new Label("Afstand fra din hjemmeadresse til arbejde og retur");

        spørgsmål2 = new Label("Ekstra kørsel ifm. indkøb, aflevere børn, køre i fitness etc.   ");

        fastKørsel = new TextField();
        fastKørsel.setPromptText("Indtast fast kørsel pr. dag");
        fastKørsel.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus();
                firstTime.setValue(false);
            }
        });

        fastKørsel.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            if (!newValue.matches("\\d*")) {
                fastKørsel.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        øvrigKørsel = new TextField();
        øvrigKørsel.setPromptText("Indtast øvrig kørsel pr. dag");
        øvrigKørsel.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            if (!newValue.matches("\\d*")) {
                øvrigKørsel.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        km1 = new Label("km");
        km1.setId("km-label");

        km2 = new Label("km");
        km2.setId("km-label");

        fejlbesked = new Label("Du skal indtaste et helt tal\ni begge felter");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

                faktaboks = new Label("Vidste du, at en elbils reelle rækkevidde "
                        + "afhænger af mange forskellige faktorer? Din kørestil, "
                        + "temperaturen udenfor og hvor meget vægt du har i bilen, "
                        + "påvirker bl.a. dette.");
                
        faktaboks.setId("faktaboks-label");

        centerGrid = new GridPane();

        centerGrid.add(spørgsmål1, 0, 0);
        centerGrid.add(spørgsmål2, 0, 1);
        centerGrid.add(fastKørsel, 1, 0);
        centerGrid.add(km1, 2, 0);
        centerGrid.add(øvrigKørsel, 1, 1);
        centerGrid.add(km2, 2, 1);
        centerGrid.add(fejlbesked, 1, 2);
        centerGrid.add(faktaboks, 0, 3, 3, 1);

        centerGrid.setId("centergrid-1");

        BorderPane.setMargin(centerGrid, new Insets(8, 0, 8, 0));

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            Forside forside = new Forside(elbilBase, brugerBase, bruger);
            getScene().setRoot(forside);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if (fastKørsel.getText().isEmpty() || øvrigKørsel.getText().isEmpty()) {
                fejlbesked.setVisible(true);
            } else {
                // Hvis der er en korrekt værdi i begge felter, sæt brugerens kørselsbehov når der trykkes "Næste"
                int daglig = Integer.parseInt(fastKørsel.getText());
                int øvrig = Integer.parseInt(øvrigKørsel.getText());
                bruger.getBehov().setFast_kørsel( daglig );
                bruger.getBehov().setØvrig_kørsel(øvrig);
                int dagligKørsel = bruger.getBehov().getFast_kørsel() + bruger.getBehov().getØvrig_kørsel();
                    System.out.println( bruger.getFornavn() + " kører dagligt: " + dagligKørsel + " km" );
                    
                    // angiv point ud fra daglig kørte km:
                    if( dagligKørsel <= 150 ) {
                        bruger.getBehov().addToScore(100);
                    } else if( dagligKørsel >= 151 && dagligKørsel <= 250 ) {
                        bruger.getBehov().addToScore(75);
                    } else if( dagligKørsel >= 251 && dagligKørsel <= 350 ) {
                        bruger.getBehov().addToScore(50);
                    } else if( dagligKørsel >= 351 && dagligKørsel <= 500 ) {
                        bruger.getBehov().addToScore(25);
                    } else if( dagligKørsel > 500 ) {
                        bruger.getBehov().addToScore(0);
                    }
                    System.out.println("Brugerens score er nu: " + bruger.getBehov().getScore());
                    
                        TestSide2 testside2 = new TestSide2(elbilBase, brugerBase, bruger);
                        getScene().setRoot(testside2);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
        
    }
}
