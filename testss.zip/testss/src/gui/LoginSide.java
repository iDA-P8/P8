/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * @author jakobbakhummelgaard
 */
public class LoginSide extends BorderPane {
    
    TextField brugerFelt;
    PasswordField kodeordFelt;
    Label overskrift, brugernavn, kodeord, status;
    Hyperlink opretBruger;
    Button login;
    
   
    
    GridPane grid;
    
    public LoginSide(ArrayList<Elbil> elbilBase, BrugerBase brugerBase ) {
        

        
        overskrift = new Label("Velkommen");
        brugernavn = new Label("Email:");
        kodeord = new Label("Kodeord:");
        
        status = new Label("Ukendt brugernavn eller kodeord");
        status.setOpacity(0);
        
        opretBruger = new Hyperlink("Opret bruger");
        opretBruger.setOnAction((ActionEvent event) -> {
            OpretBruger opretbruger = new OpretBruger(elbilBase, brugerBase);
            getScene().setRoot(opretbruger);
        });
        
        brugerFelt = new TextField();
        kodeordFelt = new PasswordField();
        
        login = new Button("Login");
        login.setOnAction((ActionEvent event) -> {
            
            if(brugerBase.erOprettet(brugerFelt.getText(), kodeordFelt.getText()) ) {
                // hent brugeren
                Bruger bruger = brugerBase.hentBruger(brugerFelt.getText(), kodeordFelt.getText());
                Forside forside = new Forside(elbilBase, brugerBase, bruger );
                getScene().setRoot(forside);
            } else {
                status.setOpacity(100);
            }
        });
        
        grid = new GridPane();
        
        grid.add(overskrift, 0, 0);
        grid.add(brugernavn, 0, 1);
        grid.add(kodeord, 0, 2);
        grid.add(status, 0, 3);
        grid.add(brugerFelt, 1, 1);
        grid.add(kodeordFelt, 1, 2);
        grid.add(login, 1, 3);
        grid.add(opretBruger, 0, 4);
        
        setCenter(grid);
    }
}
