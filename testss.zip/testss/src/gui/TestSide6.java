/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import model.Besvarelse;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * SYSTEMATISK
 *
 * @author jakobbakhummelgaard
 */
public class TestSide6 extends BorderPane {

    Label overskrift, underoverskrift, progress, spørgsmål, fejlbesked,
            faktaboks;

    RadioButton høj, nogen, mindre;
    ToggleGroup gruppe;

    Button tilbage, afslutTest;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox, faktaVbox;

    public TestSide6(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Elbiltesten");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om dig selv");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.87);
        progressbar.setId("progressbar");
        
        progress = new Label("87%", progressbar);
        
        topBox = new VBox(overskrift, underoverskrift, progress);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Vil du beskrive dig selv som\nen struktureret "
                + "person?");

        gruppe = new ToggleGroup();
        
        høj = new RadioButton("I høj grad");
        høj.setToggleGroup(gruppe);
        høj.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        nogen = new RadioButton("I nogen grad");
        nogen.setToggleGroup(gruppe);  

        mindre = new RadioButton("I mindre grad");
        mindre.setToggleGroup(gruppe);        
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("Elbilen tilbyder endnu ikke den samme frihed som en "
                + "konventionel bil når det kommer til\nlængere ture. Derfor er det "
                + "en vigtig egenskab at være god til at planlægge og stukturere\n"
                + "sine ture, når man ejer en elbil."); 
        faktaboks.setId("faktaboks-label");
        
        faktaVbox = new VBox(faktaboks);
        faktaVbox.getStyleClass().add("vbox-fakta");
        
        centerGrid = new GridPane();

        centerGrid = new GridPane();
        centerGrid.add(spørgsmål, 0, 0, 1, 3);
        centerGrid.add(høj, 1, 0);
        centerGrid.add(nogen, 1, 1);
        centerGrid.add(mindre, 1, 2);         
        centerGrid.add(fejlbesked, 1, 3);
        centerGrid.add(faktaVbox, 0, 4, 3, 1);

        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));

        for (int i = 0; i < 5; i++) {
            if (i < 4) {
                RowConstraints row = new RowConstraints(50);
                centerGrid.getRowConstraints().add(row);
            } else {
                RowConstraints row = new RowConstraints(160);
                centerGrid.getRowConstraints().add(row);
            }
        }

        centerGrid.setId("centergrid");

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide5 testside5 = new TestSide5(elbilBase, brugerBase, bruger);
            getScene().setRoot(testside5);
        });

        afslutTest = new Button("Se mit resultat");
        afslutTest.setOnAction((ActionEvent event) -> {
            if (høj.isSelected() || nogen.isSelected() 
                    || mindre.isSelected()) {
                
                // Ryd først indexet i arraylisten med besvarelser:
                if( bruger.getBehov().getBesvarelser().size() == 6 ) {
                bruger.getBehov().getBesvarelser().remove(5);
                }                
                
                Besvarelse besvarelse = new Besvarelse("spørgsmål 6");
                
                // Sæt struktureret_person til at være det valgte svar:
                if(høj.isSelected()) {
                    besvarelse.setSpørgsmålSvar( høj.getText() );
                    besvarelse.tilføjTilScore(100, 0, 0, 0, 0);
                    besvarelse.setSvar_uddybning("Du er i høj grad en struktureret person");
                } else if(nogen.isSelected()) {
                    besvarelse.setSpørgsmålSvar( nogen.getText() );
                    besvarelse.tilføjTilScore(75, 0, 0, 0, 0);
                    besvarelse.setSvar_uddybning("Du er i nogen grad en struktureret person");
                } else if(mindre.isSelected()) {
                    besvarelse.setSpørgsmålSvar( mindre.getText() );
                    besvarelse.tilføjTilScore(50, 0, 0, 0, 0);
                    besvarelse.setSvar_uddybning("Du er i mindre grad struktureret person");
                }
                
                bruger.getBehov().tilføjBesvarelse(besvarelse, 5);  
                
                // *TEST* om brugeren har fået de rigtige score:
                System.out.println("SPØRGSMÅL 6:");
                System.out.println("Antal besvarelser i array: " + bruger.getBehov().getBesvarelser().size());                
                bruger.getBehov().udprintAlleScore( bruger.getFornavn() );
                
                Resultatside resultat = new Resultatside(elbilBase, brugerBase, bruger);
                getScene().setRoot(resultat);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, afslutTest);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
