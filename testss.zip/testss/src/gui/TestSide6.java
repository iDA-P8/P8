/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * SYSTEMATISK
 *
 * @author jakobbakhummelgaard
 */
public class TestSide6 extends BorderPane {

    Label overskrift, underoverskrift, spørgsmål, fejlbesked,
            faktaboks;

    RadioButton høj, nogen, mindre;
    ToggleGroup gruppe;

    Button tilbage, afslutTest;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox;

    public TestSide6(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Spørgsmål 6");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om dig selv");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.875);
        progressbar.setId("progressbar");

        topBox = new VBox(overskrift, underoverskrift, progressbar);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Vil du beskrive dig selv som\nen struktureret "
                + "person?");

        gruppe = new ToggleGroup();
        
        høj = new RadioButton("I høj grad");
        høj.setToggleGroup(gruppe);
        høj.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        nogen = new RadioButton("I nogen grad");
        nogen.setToggleGroup(gruppe);  

        mindre = new RadioButton("I mindre grad");
        mindre.setToggleGroup(gruppe);        
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("Elbilen tilbyder endnu ikke den samme frihed som en "
                + "konventionel bil når det kommer til\nlængere ture. Derfor er det "
                + "en vigtig egenskab at være god til at planlægge og stukturere\n"
                + "sine ture, når man ejer en elbil."); 
        faktaboks.setId("faktaboks-label");

        centerGrid = new GridPane();

        centerGrid = new GridPane();
        centerGrid.add(spørgsmål, 0, 0, 1, 3);
        centerGrid.add(høj, 1, 0);
        centerGrid.add(nogen, 1, 1);
        centerGrid.add(mindre, 1, 2);         
        centerGrid.add(fejlbesked, 1, 3);
        centerGrid.add(faktaboks, 0, 4, 3, 1);
        
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));

        centerGrid.setId("centergrid-2");

        BorderPane.setMargin(centerGrid, new Insets(8, 0, 8, 0));

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide5 testside5 = new TestSide5(elbilBase, brugerBase, bruger);
            getScene().setRoot(testside5);
        });

        afslutTest = new Button("Se mit resultat");
        afslutTest.setOnAction((ActionEvent event) -> {
            if (høj.isSelected() || nogen.isSelected() 
                    || mindre.isSelected()) {
                
                // Sæt struktureret_person til at være det valgte svar:
                if(høj.isSelected()) {
                    bruger.getBehov().setStruktureret_person(høj.getText() );
                    bruger.getBehov().addToScore(100);
                } else if(nogen.isSelected()) {
                    bruger.getBehov().setStruktureret_person(nogen.getText() );
                    bruger.getBehov().addToScore(75);
                } else if(mindre.isSelected()) {
                    bruger.getBehov().setStruktureret_person(mindre.getText() );
                    bruger.getBehov().addToScore(50);
                }
                System.out.println(bruger.getFornavn() + " betegner sig selv som en struktureret person: " 
                         + bruger.getBehov().getStruktureret_person());  
                System.out.println("brugerens score er nu: " + bruger.getBehov().getScore());
                
                Resultatside resultat = new Resultatside(elbilBase, brugerBase, bruger);
                getScene().setRoot(resultat);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, afslutTest);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
