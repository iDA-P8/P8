/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testDesigns;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Forside1 extends BorderPane {

    Label overskrift, underoverskrift, bilbeskrivelse, bilnavn, pris, rækkevidde, sæder,
            ladetidHjemme, ladetidUde, testbeskrivelse;

    Image vw_eup_billede, nissan_leaf_billede, hyundai_ioniq_billede, tesla_model3_billede,
            google_maps_billede;

    ImageView vw_eup, nissan_leaf, hyundai_ioniq, tesla_model3, google_maps;

    Button start;

    VBox bil1, bil1billede, bil2, bil2billede, bil3, bil3billede, bil4, bil4billede, højre;

    GridPane topGrid, leftGrid;

    Font academySansBold45 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 45);
    Font academySandBold30 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 30);
    Font academySansBold20 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 20);
    Font academySans20 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 20);
    Font academySans15 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 15);
    Font academySans14 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 14);
    

    public Forside1() {

        // Venstre af borderpane
        /*
        BIL 1
         */
        bilbeskrivelse = new Label("Eksempler på elbiler");
        bilbeskrivelse.setFont(academySandBold30);
        bilbeskrivelse.setPadding(new Insets(10, 10, 0, 10));

        vw_eup_billede = new Image(getClass().getResourceAsStream("/billeder/vw_eup.jpg"));
        vw_eup = new ImageView(vw_eup_billede);
        vw_eup.setFitHeight(150);
        vw_eup.setPreserveRatio(true);
        vw_eup.setSmooth(true);
        vw_eup.setCache(true);

        bilnavn = new Label("Volkswagen e-Up!");
        bilnavn.setFont(academySansBold20);

        pris = new Label("Fra kr. 162.995");
        pris.setFont(academySans15);

        rækkevidde = new Label("Rækkevidde: 258 km");
        rækkevidde.setFont(academySans14);

        sæder = new Label("Antal sæder: 4");
        sæder.setFont(academySans14);

        ladetidHjemme = new Label("Ladetid hjemme: Ca. 5 timer");
        ladetidHjemme.setFont(academySans14);

        ladetidUde = new Label("Ladetid ude: Ca. 60 minutter");
        ladetidUde.setFont(academySans14);

        bil1 = new VBox(bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde);
        VBox.setMargin(bilnavn, new Insets(10, 10, 0, 10));
        VBox.setMargin(pris, new Insets(0, 10, 10, 10));
        VBox.setMargin(rækkevidde, new Insets(0, 10, 0, 10));
        VBox.setMargin(sæder, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidHjemme, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidUde, new Insets(0, 10, 10, 10));

        bil1billede = new VBox(vw_eup);
        bil1billede.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80),
                Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
                BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID,
                CornerRadii.EMPTY, new BorderWidths(2), new Insets(10, 0, 0, 10))));

        bil1.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80),
                Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
                BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
                CornerRadii.EMPTY, new BorderWidths(2), new Insets(10, 10, 0, 0))));
        bil1.setPrefWidth(300);

        /*
        BIL 2
         */
        nissan_leaf_billede = new Image(getClass().getResourceAsStream("/billeder/nissan_leaf.jpg"));
        nissan_leaf = new ImageView(nissan_leaf_billede);
        nissan_leaf.setFitHeight(150);
        nissan_leaf.setPreserveRatio(true);
        nissan_leaf.setSmooth(true);
        nissan_leaf.setCache(true);

        bilnavn = new Label("Nissan Leaf");
        bilnavn.setFont(academySansBold20);

        pris = new Label("Fra kr. 199.995");
        pris.setFont(academySans15);

        rækkevidde = new Label("Rækkevidde: 300 km");
        rækkevidde.setFont(academySans14);

        sæder = new Label("Antal sæder: 5");
        sæder.setFont(academySans14);

        ladetidHjemme = new Label("Ladetid hjemme: Ca. 6 timer");
        ladetidHjemme.setFont(academySans14);

        ladetidUde = new Label("Ladetid ude: Ca. 30 minutter");
        ladetidUde.setFont(academySans14);

        bil2 = new VBox(bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde);
        VBox.setMargin(bilnavn, new Insets(10, 10, 0, 10));
        VBox.setMargin(pris, new Insets(0, 10, 10, 10));
        VBox.setMargin(rækkevidde, new Insets(0, 10, 0, 10));
        VBox.setMargin(sæder, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidHjemme, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidUde, new Insets(0, 10, 10, 10));

        bil2billede = new VBox(nissan_leaf);
        bil2billede.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80),
                Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
                BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID,
                CornerRadii.EMPTY, new BorderWidths(2), new Insets(10, 0, 0, 10))));

        bil2.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80),
                Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
                BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
                CornerRadii.EMPTY, new BorderWidths(2), new Insets(10, 10, 0, 0))));
        bil2.setPrefWidth(300);

        /*
        BIL 3
         */
        hyundai_ioniq_billede = new Image(getClass().getResourceAsStream("/billeder/hyundai_ioniq.jpg"));
        hyundai_ioniq = new ImageView(hyundai_ioniq_billede);
        hyundai_ioniq.setFitHeight(150);
        hyundai_ioniq.setPreserveRatio(true);
        hyundai_ioniq.setSmooth(true);
        hyundai_ioniq.setCache(true);

        bilnavn = new Label("Hyundai Ioniq");
        bilnavn.setFont(academySansBold20);

        pris = new Label("Fra kr. 199.995");
        pris.setFont(academySans15);

        rækkevidde = new Label("Rækkevidde: 300 km");
        rækkevidde.setFont(academySans14);

        sæder = new Label("Antal sæder: 5");
        sæder.setFont(academySans14);

        ladetidHjemme = new Label("Ladetid hjemme: Ca. 6 timer");
        ladetidHjemme.setFont(academySans14);

        ladetidUde = new Label("Ladetid ude: Ca. 30 minutter");
        ladetidUde.setFont(academySans14);

        bil3 = new VBox(bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde);
        VBox.setMargin(bilnavn, new Insets(10, 10, 0, 10));
        VBox.setMargin(pris, new Insets(0, 10, 10, 10));
        VBox.setMargin(rækkevidde, new Insets(0, 10, 0, 10));
        VBox.setMargin(sæder, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidHjemme, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidUde, new Insets(0, 10, 10, 10));

        bil3billede = new VBox(hyundai_ioniq);
        bil3billede.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80),
                Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
                BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID,
                CornerRadii.EMPTY, new BorderWidths(2), new Insets(10, 0, 0, 10))));

        bil3.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80),
                Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
                BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
                CornerRadii.EMPTY, new BorderWidths(2), new Insets(10, 10, 0, 0))));
        bil3.setPrefWidth(300);

        /*
        BIL 4
         */
        tesla_model3_billede = new Image(getClass().getResourceAsStream("/billeder/tesla_model3.jpg"));
        tesla_model3 = new ImageView(tesla_model3_billede);
        tesla_model3.setFitHeight(150);
        tesla_model3.setPreserveRatio(true);
        tesla_model3.setSmooth(true);
        tesla_model3.setCache(true);

        bilnavn = new Label("Tesla Model 3");
        bilnavn.setFont(academySansBold20);

        pris = new Label("Fra kr. 199.995");
        pris.setFont(academySans15);

        rækkevidde = new Label("Rækkevidde: 300 km");
        rækkevidde.setFont(academySans14);

        sæder = new Label("Antal sæder: 5");
        sæder.setFont(academySans14);

        ladetidHjemme = new Label("Ladetid hjemme: Ca. 6 timer");
        ladetidHjemme.setFont(academySans14);

        ladetidUde = new Label("Ladetid ude: Ca. 30 minutter");
        ladetidUde.setFont(academySans14);

        bil4 = new VBox(bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde);
        VBox.setMargin(bilnavn, new Insets(10, 10, 0, 10));
        VBox.setMargin(pris, new Insets(0, 10, 10, 10));
        VBox.setMargin(rækkevidde, new Insets(0, 10, 0, 10));
        VBox.setMargin(sæder, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidHjemme, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidUde, new Insets(0, 10, 10, 10));

        bil4billede = new VBox(tesla_model3);
        bil4billede.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80),
                Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
                BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID,
                CornerRadii.EMPTY, new BorderWidths(2), new Insets(10, 0, 0, 10))));
        
        bil4.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80),
                Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
                BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
                CornerRadii.EMPTY, new BorderWidths(2), new Insets(10, 10, 0, 0))));
        bil4.setPrefWidth(300);

        leftGrid = new GridPane();

        leftGrid.add(bilbeskrivelse, 0, 0);
        leftGrid.add(bil1billede, 0, 1);
        leftGrid.add(bil1, 1, 1);
        leftGrid.add(bil2billede, 0, 2);
        leftGrid.add(bil2, 1, 2);
        leftGrid.add(bil3billede, 0, 3);
        leftGrid.add(bil3, 1, 3);
        leftGrid.add(bil4billede, 0, 4);
        leftGrid.add(bil4, 1, 4);

        leftGrid.setAlignment(Pos.CENTER_RIGHT);
        
        setLeft(leftGrid);

        // Højre af borderpane
        overskrift = new Label("Fremtiden er\nelektrisk");
        overskrift.setFont(academySansBold45);
        //overskrift.setTextFill(Color.rgb(54, 128, 45));

        underoverskrift = new Label("Elbilguiden fortæller dig kort og præcist, "
                + "om et skifte til elbil ville\nfungere for dig og opfylde dine behov");
        underoverskrift.setFont(academySans20);

        /*topGrid = new GridPane();
        topGrid.add(overskrift,0,0);
        topGrid.setAlignment(Pos.CENTER);
        topGrid.setPadding(new Insets(12));
        topGrid.setVgap(12);
        topGrid.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80), 
            Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
            BorderStrokeStyle.NONE, BorderStrokeStyle.NONE, 
            BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
            CornerRadii.EMPTY, new BorderWidths(1), Insets.EMPTY)));

        setTop(topGrid);*/
        google_maps_billede = new Image(getClass().getResourceAsStream("/billeder/googlemaps.jpg"));
        google_maps = new ImageView(google_maps_billede);
        google_maps.setFitHeight(400);
        google_maps.setPreserveRatio(true);
        google_maps.setSmooth(true);
        google_maps.setCache(true);

        testbeskrivelse = new Label("Find ud af om en elbil er det rette for dig");
        testbeskrivelse.setFont(academySansBold20);

        start = new Button("Start elbilstesten");
        start.setFont(academySansBold20);
        start.setPrefHeight(60);
        start.setStyle("-fx-background-color: rgb(75, 169, 80); -fx-text-fill: white;");

        højre = new VBox();
        højre.getChildren().addAll(overskrift, underoverskrift, google_maps, testbeskrivelse, start);

        højre.setAlignment(Pos.BOTTOM_CENTER);
        højre.setSpacing(10);
        højre.setPadding(new Insets(10, 50, 10, 50));
 
        højre.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80), 
            Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
            BorderStrokeStyle.NONE, BorderStrokeStyle.NONE, 
            BorderStrokeStyle.NONE, BorderStrokeStyle.SOLID,
            CornerRadii.EMPTY, new BorderWidths(1), Insets.EMPTY)));

        /*
        
        GridPane.setHalignment(testbeskrivelse, HPos.CENTER);        
        GridPane.setHalignment(start, HPos.CENTER);

                
        bottomGrid.setAlignment(Pos.CENTER);
        bottomGrid.setPadding(new Insets(12));
        //bottomGrid.setHgap(25);
        bottomGrid.setVgap(12);
        bottomGrid.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80), 
            Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
            BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE, 
            BorderStrokeStyle.NONE, BorderStrokeStyle.NONE,
            CornerRadii.EMPTY, new BorderWidths(1), Insets.EMPTY)));
         */
        setRight(højre);
        //højre.setStyle("-fx-border-color: #001E50; -fx-border-width: 2");


        this.setStyle("-fx-background-color: white;");
    }
}

/*bil1venstre.setBorder(new Border(new BorderStroke(Color.LIGHTGREY, Color.LIGHTGREY, Color.LIGHTGREY, Color.LIGHTGREY,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE, BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID,
                CornerRadii.EMPTY, new BorderWidths(2), Insets.EMPTY)));*/
//bil1højre = new VBox();
/*bil1højre.setBorder(new Border(new BorderStroke(Color.LIGHTGREY, Color.LIGHTGREY, Color.LIGHTGREY, Color.LIGHTGREY,
                BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
                CornerRadii.EMPTY, new BorderWidths(2), Insets.EMPTY)));*/
//bil1.getChildren().addAll(bilbillede, bilnavn, pris, rækkevidde, sæder);
        //bil1højre.getChildren().addAll(km, antalsæder);
