/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elbilstesten;

import gui.Forside;
import gui.LoginSide;
import gui.Opladning;
import gui.OpretBruger;
import gui.Resultatside;
import gui.TestSide1;
import gui.TestSide2;
import gui.TestSide3;
import testDesigns.Forside1;
import testDesigns.TestSide;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.geometry.Rectangle2D;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import model.Bruger;
import model.BrugerBase;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Elbilstesten extends Application {

    Font academySansBold45 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 45);
    Font academySans24 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 24);
    Font academySansLightItalic18 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-LightItalic.ttf"), 18);
    Font academySansLight18 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Light.ttf"), 18);
    Font academySansDemiBold16 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-DemiBold.ttf"), 16);

    @Override
    public void start(Stage primaryStage) throws Exception {

        BrugerBase brugerbase = new BrugerBase();
        
        Forside forside = new Forside();
        Forside1 forside1 = new Forside1();
        LoginSide login = new LoginSide(brugerbase);
        TestSide1 testside1 = new TestSide1();
        TestSide2 testside2 = new TestSide2();
        TestSide3 testside3 = new TestSide3();
        Opladning opladning = new Opladning();
        Resultatside resultat = new Resultatside();

        Scene scene = new Scene(resultat, 1280, 720);

        primaryStage.setTitle("Elbilsten");
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String args[]) {
        launch(args);
    }
}
