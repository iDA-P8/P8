/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Resultatside extends BorderPane {
    
    Label score, dagligKørselOverskrift, dagligKørselIntro, dagligKørselSvar1,
            dagligKørselSvar2, dagligKørselUddybning;
    Button button;
    VBox dagligKørselBox;
    
    Tab dagligKørselTab, bilensStørrelseTab, øvrigeForholdTab;
    TabPane tabpane;
    
public Resultatside() {
    
    score = new Label("DINE RESULTATER ER\n 92/100");
    
    button = new Button("hejsa");
    button.setOnAction((ActionEvent event) -> {
            Forside forside = new Forside();
            getScene().setRoot(forside);
        });
    
    setTop(button);
    
    //TABPANE
    dagligKørselOverskrift = new Label("Daglig Kørsel");
    dagligKørselIntro = new Label("Du er mere end klar til livet som "
            + "elbilllist, og et skifte fra din nuværende bil vil ikke "
            + "påvirke dine daglige rutiner.");
    dagligKørselSvar1 = new Label("- Du har 50 km til og fra arbejde");
    dagligKørselSvar2 = new Label("- Du kører 20 km sporadisk kørsel om dagen");
    dagligKørselUddybning = new Label("Dine daglige køreture passer godt til "
            + "en elbils rækkevidde. En VW e-Up! har en rækkevidde op til 260 "
            + "km, hvor du kan forvente en reel rækkevidde op til 180 km");
    
    dagligKørselBox = new VBox(dagligKørselOverskrift, dagligKørselIntro, 
            dagligKørselSvar1, dagligKørselSvar2, dagligKørselUddybning);
    
    dagligKørselTab = new Tab("Daglig kørsel");
    dagligKørselTab.setContent(dagligKørselBox);
    
    
    bilensStørrelseTab = new Tab("Bilens størrelse");
    øvrigeForholdTab = new Tab("Øvrige forhold");
    tabpane = new TabPane(dagligKørselTab, bilensStørrelseTab, øvrigeForholdTab);
    tabpane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
    
    
   this.getStylesheets().add("/css/resultatside.css");
   dagligKørselOverskrift.setId("overskrift");
       
    setCenter(tabpane);
    
}
    
}
