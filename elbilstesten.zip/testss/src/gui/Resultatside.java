/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.NodeOrientation;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.scene.text.TextAlignment;

/** 
 *
 * @author jakobbakhummelgaard
 */
public class Resultatside extends BorderPane {

    Label overskrift, rubrik, biloverskrift, bilrubrik, dagligKørselOverskrift,
            dagligKørselIntro, dagligKørselSvar1, dagligKørselSvar2,
            dagligKørselUddybning, point0, point50, point100, skalaForklaring;

    Label bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde;

    Label kol1, kol2, kol3, ræk1, ræk2, ræk3, ræk4, celB1, celB2, celB3, celC3,
            celC4, celD3, celD4;

    Rectangle skala, baggrundGridpane;

    Image blad_billede, brændstof_billede, vw_eup_billede, spørgsmålstegn_billede;

    ImageView blad, brændstof, vw_eup, spørgsmålstegn1, spørgsmålstegn2;

    Button button;
    VBox resultat, bilForklaringBox, bil, bilbillede, dagligKørselBox;

    TableView kmTable;
    TableColumn kolonne1, kolonne2, kolonne3, kolonne4;

    GridPane topGrid, bilGrid, kmGrid;

    Pane brændstofPane, bladPane;
    StackPane skalaStack;

    Tab dagligKørselTab, bilensStørrelseTab, øvrigeForholdTab;
    TabPane tabpane;

    BorderPane dagligKørselBorderPane;

    public Resultatside() {

        // TOPPEN AF BORDERPANE
        
        ProgressBar progress = new ProgressBar(0.92);
        progress.setId("progressbar-skala");
        
        // Del 1: Overordnet resultatboks
        overskrift = new Label("Dit resultat:\n92/100");
        overskrift.setId("overskrift-label");

        rubrik = new Label("Når du har scoret 92 point betyder det, at en elbil passer rigtig godt til dig og dine behov.\n"
                + "Læs dine specifikke resultater nederst og bliv klogere på hvor godt en elbil passer til dig.");
        rubrik.setId("forklaring-label");

        resultat = new VBox(overskrift, rubrik);
        resultat.setId("vbox-resultat");
        
        // Del 2: Pointskala
        skalaForklaring = new Label("Pointskala");
        skalaForklaring.setId("skala-forklaring");

        skala = new Rectangle(400, 25);
        skala.setId("linear-gradient");

        point0 = new Label("0");
        point0.setId("point0-label");

        point50 = new Label("50");
        point50.setId("point50-label");

        point100 = new Label("100");
        point100.setId("point100-label");

        blad_billede = new Image(getClass().getResourceAsStream("/billeder/blad-ikon.png"));
        blad = new ImageView(blad_billede);
        blad.setFitWidth(35);
        blad.setPreserveRatio(true);
        blad.setSmooth(true);
        blad.setCache(true);

        brændstof_billede = new Image(getClass().getResourceAsStream("/billeder/braendstof-ikon.png"));
        brændstof = new ImageView(brændstof_billede);
        brændstof.setFitWidth(25);
        brændstof.setPreserveRatio(true);
        brændstof.setSmooth(true);
        brændstof.setCache(true);

        bladPane = new Pane(blad);
        bladPane.setId("blad-pane");
        bladPane.setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);

        brændstofPane = new Pane(brændstof);
        brændstofPane.setId("braendstof-pane");

        skalaStack = new StackPane(skalaForklaring, skala, point0, point50, point100, brændstofPane, bladPane);
        skalaStack.getStylesheets().add("/css/resultat-skala.css");

        // Del 3: Forslag til elbil
        biloverskrift = new Label("Bedste elbil til dig");
        biloverskrift.setId("overskrift-label");

        bilrubrik = new Label("På baggrund af dine svar i testen anbefaler vi en "
                + "Volkswagen e-Up! som det bedste bilkøb til dig, hvis du vælger "
                + "at købe en elbil.");      
        bilrubrik.setId("rubrik-label");

        vw_eup_billede = new Image(getClass().getResourceAsStream("/billeder/vw_eup.jpg"));
        vw_eup = new ImageView(vw_eup_billede);
        vw_eup.setFitHeight(150);
        vw_eup.setPreserveRatio(true);
        vw_eup.setSmooth(true);
        vw_eup.setCache(true);

        bilnavn = new Label("Volkswagen e-Up!");
        bilnavn.setId("bilnavn-label");

        pris = new Label("Fra kr. 162.995");
        pris.setId("pris-label");

        rækkevidde = new Label("Rækkevidde: 258 km");
        rækkevidde.setId("bilinfo-label");

        sæder = new Label("Antal sæder: 4");
        sæder.setId("bilinfo-label");

        ladetidHjemme = new Label("Ladetid hjemme: Ca. 5 timer");
        ladetidHjemme.setId("bilinfo-label");

        ladetidUde = new Label("Ladetid ude: Ca. 60 minutter");
        ladetidUde.setId("bilinfo-label");

        bil = new VBox(bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde);
        bil.getStyleClass().add("vbox");

        bilbillede = new VBox(vw_eup);
        bilbillede.setId("bilbillede-vbox");


        bilGrid = new GridPane();
        bilGrid.setId("bilgrid");

        bilGrid.add(bilbillede, 0, 1);
        bilGrid.add(bil, 1, 1);
        
        
        bilForklaringBox = new VBox(biloverskrift, bilGrid, bilrubrik);
        bilForklaringBox.setId("vbox-bil-resultat");  

        // Tilføj Del 1, 2 og 3 til toppen af borderpane via en gridpane      
        topGrid = new GridPane();

        topGrid.add(resultat, 0, 0);
        topGrid.add(skalaStack, 0, 1);
        topGrid.add(bilForklaringBox, 1, 0, 1, 2);

        topGrid.getColumnConstraints().add(new ColumnConstraints(617));
        topGrid.getColumnConstraints().add(new ColumnConstraints(618));

        topGrid.getRowConstraints().add(new RowConstraints(165));
        topGrid.getRowConstraints().add(new RowConstraints(165));

        topGrid.setId("topgrid");

        setTop(topGrid);

        //TABPANE
        dagligKørselBorderPane = new BorderPane();

        // TAB 1 DAGLIG KØRSEL
        dagligKørselOverskrift = new Label("Daglig Kørsel");
        dagligKørselIntro = new Label("Dine daglige kørselsmønstre er ideelle for en "
                + "elbils rækkevidde, fordi du ikke kører flere\nkm, end hvad der er "
                + "muligt for en elbil. En elbil vil derfor ikke kræve, at du ændrer\n"
                + "på dine daglige rutiner.");
        dagligKørselUddybning = new Label("Vi har anbefalet en VW e-Up! som den mest "
                + "passende elbil til dine behov. En VW e-Up!\nhar en rækkevidde på op "
                + "til 280 km, hvor du kan forvente en reel rækkevidde 180 km.");

        dagligKørselBox = new VBox(dagligKørselOverskrift, dagligKørselIntro, dagligKørselUddybning);
        dagligKørselBox.setId("vbox-daglig-koersel");

        dagligKørselTab = new Tab("Daglig kørsel");
        dagligKørselTab.setContent(dagligKørselBorderPane);
        dagligKørselBorderPane.setId("borderpane-daglig-koersel");

        dagligKørselBorderPane.setLeft(dagligKørselBox);

        bilensStørrelseTab = new Tab("Bilens størrelse");
        øvrigeForholdTab = new Tab("Øvrige forhold");
        tabpane = new TabPane(dagligKørselTab, bilensStørrelseTab, øvrigeForholdTab);
        tabpane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        // Km tabel under Daglig kørsel
        spørgsmålstegn_billede = new Image(getClass().getResourceAsStream("/billeder/info-black.png"));
        spørgsmålstegn1 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn1.setFitWidth(16);
        spørgsmålstegn1.setPreserveRatio(true);
        spørgsmålstegn1.setSmooth(true);
        spørgsmålstegn1.setCache(true);

        spørgsmålstegn2 = new ImageView(spørgsmålstegn_billede);
        spørgsmålstegn2.setFitWidth(15);
        spørgsmålstegn2.setPreserveRatio(true);
        spørgsmålstegn2.setSmooth(true);
        spørgsmålstegn2.setCache(true);

        kol1 = new Label("Du kører");
        kol1.setId("kolonner");

        kol2 = new Label("Bilens\nrækkevidde");
        kol2.setId("kolonner");

        kol3 = new Label("Bilens reelle\nrækkevidde");
        kol3.setId("kolonner");

        ræk1 = new Label("Fast daglig kørsel");
        ræk1.setId("almindelige");

        ræk2 = new Label("Øvrig daglig kørsel");
        ræk2.setId("almindelige");

        ræk3 = new Label("Total");
        ræk4 = new Label("Km tilovers ved\ndaglig kørsel");

        celB1 = new Label("75 km");
        celB1.setId("almindelige");

        celB2 = new Label("25 km");
        celB2.setId("almindelige");

        celB3 = new Label("100 km");
        celB3.setId("totaler");

        celC3 = new Label("280 km", spørgsmålstegn1);
        celC3.setId("totaler");

        celC4 = new Label("180 km");
        celD3 = new Label("180 km", spørgsmålstegn2);
        celD3.setId("totaler");

        celD4 = new Label("80 km");
        baggrundGridpane = new Rectangle(560, 50, Color.LIGHTGREY);

        kmGrid = new GridPane();
        kmGrid.add(baggrundGridpane, 0, 4, 4, 1);
        kmGrid.add(kol1, 1, 0);
        kmGrid.add(kol2, 2, 0);
        kmGrid.add(kol3, 3, 0);
        kmGrid.add(ræk1, 0, 1);
        kmGrid.add(ræk2, 0, 2);
        kmGrid.add(ræk3, 0, 3);
        kmGrid.add(ræk4, 0, 4);
        kmGrid.add(celB1, 1, 1);
        kmGrid.add(celB2, 1, 2);
        kmGrid.add(celB3, 1, 3);
        kmGrid.add(celC3, 2, 3);
        kmGrid.add(celC4, 2, 4);
        kmGrid.add(celD3, 3, 3);
        kmGrid.add(celD4, 3, 4);

        kmGrid.getStylesheets().add("/css/resultat_tabel.css");
        kmGrid.getStyleClass().add("grid");

        dagligKørselBorderPane.setRight(kmGrid);

        this.getStylesheets().add("/css/resultatside.css");
        dagligKørselOverskrift.setId("overskrift-label");

        setCenter(tabpane);

    }

}

//        vw_eup_billede = new Image(getClass().getResourceAsStream("/billeder/vw_eup.jpg"));
//        vw_eup = new ImageView(vw_eup_billede);
//        vw_eup.setFitWidth(225);
//        vw_eup.setPreserveRatio(true);
//        vw_eup.setSmooth(true);
//        vw_eup.setCache(true);
//
//        bilnavn = new Label("Volkswagen e-Up!");
//        bilnavn.setId("bilnavn-label");
//
//        pris = new Label("Fra kr. 162.994");
//        pris.setId("pris-label");
//
//        rækkevidde = new Label("Rækkevidde: 258 km");
//        rækkevidde.setId("bilinfo-label");
//
//        sæder = new Label("Antal sæder: 4");
//        sæder.setId("bilinfo-label");      
//
//        ladetidHjemme = new Label("Ladetid hjemme: Ca. 5 timer");
//        ladetidHjemme.setId("bilinfo-label");   
//
//        ladetidUde = new Label("Ladetid ude: 60 minutter");
//        ladetidUde.setId("bilinfo-label");
//
//        bil = new VBox(vw_eup, bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde);
//        bil.getStyleClass().add("vbox");
