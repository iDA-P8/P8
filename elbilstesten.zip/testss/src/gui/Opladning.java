package gui;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Opladning extends BorderPane {

    Label overskrift, underoverskrift, vælgBil, vælgLadetype, resultat;

    //choicebox elementer
    ChoiceBox<String> bilvalg, ladevalg;
    String[] bilmodeller, vweup_ladning, hyundaiioniq_ladning, teslamodel3_ladning;

    Image vw_eup_billede;

    ImageView vw_eup;

    Button start;

    VBox menulinje, valgmuligheder, bundBox;

    GridPane topGrid, leftGrid, bottomGrid;

    Font academySansBold45 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 45);
    Font academySansBold30 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 30);
    Font academySansBold24 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 24);
    Font academySansDemiBold20 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-DemiBold.ttf"), 20);
    Font academySans24 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 24);
    Font academySans16 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 16);
    Font academySans15 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 15);

    /**
     * Elementer til logo
     *
     */
    Rectangle rectangle, line;
    Label systemNavn, madeBy;
    Image ikon_billede;
    ImageView ikon;
    StackPane stack;

    public Opladning() {

        // Toppen af borderpane
        /**
         * Tilføj VBox'en menulinje til setTop hvis vi ønsker at have en
         * overskrift med underoverksrift.
         */
        overskrift = new Label("Elbilguiden");
        overskrift.setFont(academySansBold45);
        //overskrift.setStyle("-fx-text-fill: white;");
        //overskrift.setTextFill(Color.rgb(54, 128, 45)); 

        underoverskrift = new Label("Elbilguiden fortæller dig kort og præcist, "
                + "om et skifte til elbil ville\nfungere for dig og opfylde dine behov");
        underoverskrift.setFont(academySans24);

        menulinje = new VBox(overskrift, underoverskrift);
        menulinje.setAlignment(Pos.CENTER);
        menulinje.setSpacing(10);
        //menulinje.setStyle("-fx-background-color: #001E50;"); 

        topGrid = new GridPane();
        topGrid.add(overskrift, 0, 0);
        topGrid.setAlignment(Pos.CENTER);
        topGrid.setPadding(new Insets(12));
        topGrid.setVgap(12);
        setTop(topGrid);

        // Midten af borderpane
        // CHOICEBOX FUNKTIONALITET
        bilmodeller = new String[]{
            "VW e-Up!",
            "Hyundai Ioniq",
            "Tesla Model 3"
        };

        vweup_ladning = new String[]{
            "Hjemmeopladning v. 2,3 kWh (vha. mormorstik)",
            "Hjemmeopladning v. 7,2 kWh (vha. ladeboks)",
            "Opladning ude v. 40 kWh (vha. hurtigopladere)"
        };

        hyundaiioniq_ladning = new String[]{
            "2,3 kWh",
            "7,2 kWh",};

        teslamodel3_ladning = new String[]{
            "7,2 kWh",
            "36 kWh"
        };
        
        String svar = "5 timer";

        ObservableList<String> bil1 = FXCollections.observableArrayList(vweup_ladning);
        ObservableList<String> bil2 = FXCollections.observableArrayList(hyundaiioniq_ladning);
        ObservableList<String> bil3 = FXCollections.observableArrayList(teslamodel3_ladning);

        bilvalg = new ChoiceBox(FXCollections.observableArrayList(bilmodeller));
        bilvalg.setPrefSize(200, 50);

        ladevalg = new ChoiceBox();
        ladevalg.setPrefSize(200, 50);

        bilvalg.getSelectionModel().selectedIndexProperty().addListener(
                (ov, oldVal, newVal) -> {

                    int bilValgt = newVal.intValue();

                    if (bilValgt == 0) {
                        ladevalg.getItems().setAll(bil1);
                    }
                    if (bilValgt == 1) {
                        ladevalg.getItems().setAll(bil2);
                    }
                    if (bilValgt == 2) {
                        ladevalg.getItems().setAll(bil3);
                    }
                }
        );

        bilvalg.getSelectionModel().selectedItemProperty().addListener((ov, oldVal, newVal) -> {
            String bilmodel = newVal;
            System.out.println(bilmodel);
        });

        ladevalg.getSelectionModel().selectedItemProperty().addListener(
                (ov, oldVal, newVal) -> {

                    //METODE TIL AT FREMKALDE RESULTATET AF VALGMULIGHEDERNE
                    String ladning = newVal;

                    if(ladning.equals("Hjemmeopladning v. 7,2 kWh (vha. ladeboks)")) {
                        resultat.setText("Det vil tage: " + svar);
                    } else {
                        resultat.setText("");
                    }
                    
                   // resultat.setText("Det vil tage: " + ladning);

                }
        );

        resultat = new Label();

        vælgBil = new Label("Vælg bil");
        vælgLadetype = new Label("Vælg ladetype");

        valgmuligheder = new VBox(vælgBil, bilvalg, vælgLadetype, ladevalg, resultat);

        setCenter(valgmuligheder);

        /*Venstre af borderpane
        bilbeskrivelse = new Label("Eksempler på elbiler");
        bilbeskrivelse.setFont(academySansBold24);

        vw_eup_billede = new Image(getClass().getResourceAsStream("/billeder/vw_eup.jpg"));
        vw_eup = new ImageView(vw_eup_billede);
        vw_eup.setFitWidth(225);
        vw_eup.setPreserveRatio(true);
        vw_eup.setSmooth(true);
        vw_eup.setCache(true);

        bilnavn = new Label("Volkswagen e-Up!");
        bilnavn.setFont(academySansBold24);

        pris = new Label("Fra kr. 162.995");
        pris.setFont(academySans16);

        rækkevidde = new Label("Rækkevidde: 258 km");
        rækkevidde.setFont(academySans15);

        sæder = new Label("Antal sæder: 4");
        sæder.setFont(academySans15);

        ladetidHjemme = new Label("Ladetid hjemme: Ca. 5 timer");
        ladetidHjemme.setFont(academySans15);
        
        ladetidUde = new Label("Ladetid ude: Ca. 60 minutter");  
        ladetidUde.setFont(academySans15);    

        bil1 = new VBox(vw_eup, bilnavn, pris, rækkevidde, sæder, ladetidHjemme, ladetidUde);
        VBox.setMargin(bilnavn, new Insets(10, 10, 0, 10));
        VBox.setMargin(pris, new Insets(0, 10, 10, 10));
        VBox.setMargin(rækkevidde, new Insets(0, 10, 0, 10));
        VBox.setMargin(sæder, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidHjemme, new Insets(0, 10, 0, 10));
        VBox.setMargin(ladetidUde, new Insets(0, 10, 0, 10));

        bil1.setStyle("-fx-border-color: #001E50; -fx-border-insets: 10, 10, 10, 10; -fx-border-width: 2");
        bil1.setPrefSize(225, 300);

       

        leftGrid = new GridPane();

        leftGrid.setAlignment(Pos.CENTER);

        setLeft(leftGrid);
         */
        this.setStyle("-fx-background-color: white;");
    }

}
