/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import model.Bruger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import model.BrugerBase;

/**
 *
 * @author jakobbakhummelgaard
 */
public class OpretBruger extends BorderPane {
    
    Label overskrift, oplysninger, fornavn, efternavn, email, kodeord;
    
    TextField fornavnFelt, efternavnFelt, emailFelt;
    
    PasswordField kodeordFelt;
    
    Button opretKnap;
    
    GridPane grid;
    
    BrugerBase brugerBase;
    
    
    
    public OpretBruger(BrugerBase bb) {
        this.brugerBase = bb;
        
        overskrift = new Label("Opret bruger");
        oplysninger = new Label("Indtast dine oplysninger");
        
        
        fornavn = new Label("Fornavn");
        efternavn = new Label("Efternavn");
        email = new Label("Email");
        kodeord = new Label("Kodeord");
        
        fornavnFelt = new TextField();
        efternavnFelt = new TextField();       
        emailFelt = new TextField();    
        kodeordFelt = new PasswordField();
        
        opretKnap = new Button("OPRET");
        opretKnap.setOnAction((ActionEvent event) -> {
            
            Bruger bruger = new Bruger(fornavnFelt.getText(), efternavnFelt.getText(), emailFelt.getText(), kodeordFelt.getText());
            brugerBase.tilføjBruger(bruger);
         
            LoginSide loginSide = new LoginSide(brugerBase);
            getScene().setRoot(loginSide);
            
        });
        
        grid = new GridPane();
        
        grid.add(overskrift, 0, 0);
        grid.add(oplysninger, 0, 1);
        
        grid.add(fornavn, 0, 2);
        grid.add(fornavnFelt, 0, 3);
        
        grid.add(efternavn, 1, 2);
        grid.add(efternavnFelt, 1, 3);
        
        grid.add(email, 0, 4);
        grid.add(emailFelt, 0, 5);     
        
        grid.add(kodeord, 1, 4);
        grid.add(kodeordFelt, 1, 5);     
        
        grid.add(opretKnap, 0, 6);

        setCenter(grid);
    }
    
}


