/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * ANTAL PERSONER
 *
 * @author jakobbakhummelgaard
 */
public class TestSide5 extends BorderPane {

    Label overskrift, underoverskrift, spørgsmål, fejlbesked,
            faktaboks;

    RadioButton to, fire, fem, overFem;
    ToggleGroup gruppe;

    Button tilbage, næste;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox;

    public TestSide5() {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Spørgsmål 5");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om dine størrelseskrav til bilen");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.625);
        progressbar.setId("progressbar");

        topBox = new VBox(overskrift, underoverskrift, progressbar);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Hvor mange personer skal bilen\nkunne transportere?");

        gruppe = new ToggleGroup();
        
        to = new RadioButton("1-2 personer");
        to.setToggleGroup(gruppe);
        to.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        fire = new RadioButton("2-4 personer");
        fire.setToggleGroup(gruppe);  
        
        fem = new RadioButton("4-5 personer");
        fem.setToggleGroup(gruppe);  

        overFem = new RadioButton("Flere end 5");
        overFem.setToggleGroup(gruppe);          
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("Bor du i lejlighed skal du være opmærksom på, at "
                + "du ikke nødvendigvis kan oplade en elbil\npå din bopæl. Undersøg "
                + "derfor gerne, om der er ladestandere nær din adresse."); 
        faktaboks.setId("faktaboks-label");

        centerGrid = new GridPane();

        centerGrid = new GridPane();
        centerGrid.add(spørgsmål, 0, 0, 1, 4);
        centerGrid.add(to, 1, 0);
        centerGrid.add(fire, 1, 1);
        centerGrid.add(fem, 1, 2);
        centerGrid.add(overFem, 1, 3);     
        centerGrid.add(fejlbesked, 1, 4);
        centerGrid.add(faktaboks, 0, 5, 3, 1);
        
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));

        centerGrid.setId("centergrid-2");

        BorderPane.setMargin(centerGrid, new Insets(8, 0, 8, 0));

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide4 testside4 = new TestSide4();
            getScene().setRoot(testside4);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if (to.isSelected() || fire.isSelected() 
                    || fem .isSelected() || overFem.isSelected()) {
                TestSide6 testside6 = new TestSide6();
                getScene().setRoot(testside6);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
