/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * ANHÆNGERTRÆK
 *
 * @author jakobbakhummelgaard
 */
public class TestSide6 extends BorderPane {

    Label overskrift, underoverskrift, spørgsmål, fejlbesked,
            faktaboks;

    RadioButton skal, kan, nej;
    ToggleGroup gruppe;

    Button tilbage, næste;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox;

    public TestSide6() {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Spørgsmål 6");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om dit behov i forhold til anhængertræk");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.75);
        progressbar.setId("progressbar");

        topBox = new VBox(overskrift, underoverskrift, progressbar);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Meget få elbiler må få monteret\nanhængertræk.\n\n"
                + "Er du afhængig af at have\nanhængertræk på din bil?");

        gruppe = new ToggleGroup();
        
        skal = new RadioButton("Skal have");
        skal.setToggleGroup(gruppe);
        skal.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        kan = new RadioButton("At foretrække, men kan undvære");
        kan.setToggleGroup(gruppe);  
        
        nej = new RadioButton("Behøver ikke");
        nej.setToggleGroup(gruppe);      
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("At have mange kg på anhængertrækket er ikke en af "
                + "elbilens fordele. Elbiler under 400.000 kr.\nmå p.t. "
                + "ikke trække særlig meget vægt."); 
        faktaboks.setId("faktaboks-label");

        centerGrid = new GridPane();

        centerGrid = new GridPane();
        centerGrid.add(spørgsmål, 0, 0, 1, 4);
        centerGrid.add(skal, 1, 1);
        centerGrid.add(kan, 1, 2);
        centerGrid.add(nej, 1, 3);
        centerGrid.add(fejlbesked, 1, 4);
        centerGrid.add(faktaboks, 0, 5, 3, 1);
        
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));

        centerGrid.setId("centergrid-2");

        BorderPane.setMargin(centerGrid, new Insets(8, 0, 8, 0));

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide5 testside5 = new TestSide5();
            getScene().setRoot(testside5);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if (skal.isSelected() || kan.isSelected() 
                    || nej.isSelected()) {
                TestSide7 testside7 = new TestSide7();
                getScene().setRoot(testside7);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
