/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author alexa
 */
public class BrugerBase {
    
    private ArrayList<Bruger> brugerBase;
    
    public BrugerBase() {
        brugerBase = new ArrayList();
    }
    
    public void tilføjBruger(Bruger bruger) {
        brugerBase.add(bruger);
        System.out.println("Bruger tilføjet: " + bruger.getEmail() + " " + bruger.getKodeord());
    }
    
    public boolean findBruger(String email, String kodeord) {
        // Find bruger ved email i basen
        for(Bruger bru : brugerBase) {
            if(bru.getEmail().equals(email) &&  bru.getKodeord().equals(kodeord)) {
                System.out.println("Bruger fundet på index: " + brugerBase.indexOf(bru));
                return true;
            } else
                System.out.println("Ingen bruger fundet");
        }
        return false;
    }

    
}

