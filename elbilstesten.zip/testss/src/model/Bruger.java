/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author jakobbakhummelgaard
 */
public class Bruger { 

    private String fornavn;
    private String efternavn;
    private ArrayList<Bruger> brugere;

    public Bruger(String fornavn) {
        this.fornavn = fornavn;
        this.efternavn = efternavn;
        this.brugere = new ArrayList<>();    
    }

    public String getFornavn() {
        return fornavn;
    }
    
    public void setFornavn(String brugerFornavn) {
        fornavn = brugerFornavn;
    }
    
    public String getEfternavn() {
        return efternavn;
    }
    
    public void setEfternavn(String brugerefternavn) {
        efternavn = brugerefternavn;
    }
    
    public void tilføjBruger(Bruger bruger){
        brugere.add(bruger);
    }
    
    public ArrayList<Bruger> getBrugere() {
        return brugere;
    }
    
}
