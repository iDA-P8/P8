/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testDesigns;

import gui.*;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

/**
 * 
 * FASTE OG SPORADISKE KØRSELSMØNSTRE
 *
 * @author jakobbakhummelgaard
 */
public class TestSide1FØRCSS extends BorderPane {
    
    Label overskrift, underoverskrift, spørgsmål1, spørgsmål2, km1, km2, fejlbesked,
            faktaboks;

    TextField fastKørsel, øvrigKørsel;

    Button tilbage, næste;
    
    ProgressBar progressbar;

    GridPane centerGrid;
    
    HBox knapper;
    VBox topBox;

    Font academySansBold45 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Bold.ttf"), 45);
    Font academySans24 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans.ttf"), 24);
    Font academySansLightItalic18 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-LightItalic.ttf"), 18);    
    Font academySansLight18 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-Light.ttf"), 18);
    Font academySansDemiBold16 = Font.loadFont(getClass().getResourceAsStream("/fonts/AcademySans-DemiBold.ttf"), 16);    
    
    public TestSide1FØRCSS() {
        
    final BooleanProperty firstTime = new SimpleBooleanProperty(true);
    
        // Top of borderpane
        overskrift = new Label("Spørgsmål 1");
        overskrift.setFont(academySansBold45);
        
        underoverskrift = new Label("Fortæl os om dine daglige kørselsmønstre");
        underoverskrift.setFont(academySans24);
        
        progressbar = new ProgressBar(0.2);
        progressbar.setStyle("-fx-text-box-border: #001E50; -fx-control-inner-background: white; -fx-background-insets: 0;");
        progressbar.setPrefSize(125, 25);
                
        topBox = new VBox(overskrift, underoverskrift, progressbar);
        topBox.setPadding(new Insets(12));
        topBox.setSpacing(12);
        topBox.setMaxWidth(800);
        topBox.setAlignment(Pos.CENTER);
        topBox.setStyle("-fx-background-color: white;");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål1 = new Label("Afstand fra din hjemmeadresse til arbejde og retur");
        spørgsmål1.setFont(academySansLight18);
        spørgsmål1.setPadding(new Insets(12));
        
        spørgsmål2 = new Label("Ekstra kørsel ifm. indkøb, aflevere børn, køre i fitness etc.");
        spørgsmål2.setFont(academySansLight18);
        spørgsmål2.setPadding(new Insets(12));
        
        fastKørsel = new TextField();
        fastKørsel.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80), BorderStrokeStyle.SOLID, new CornerRadii(0), new BorderWidths(2))));
        fastKørsel.setFont(academySansLight18);
        fastKørsel.setPrefSize(225, 50);
        fastKørsel.setPromptText("Indtast fast kørsel pr. dag");
        fastKørsel.setAlignment(Pos.CENTER_RIGHT);
        fastKørsel.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        fastKørsel.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            if (!newValue.matches("\\d*")) {
                fastKørsel.setText(newValue.replaceAll("[^\\d]", ""));
            }
    });
        
        øvrigKørsel = new TextField();
        øvrigKørsel.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80), BorderStrokeStyle.SOLID, new CornerRadii(0), new BorderWidths(2))));
        øvrigKørsel.setFont(academySansLight18);
        øvrigKørsel.setPrefSize(225, 50);        
        øvrigKørsel.setPromptText("Indtast øvrig kørsel pr. dag");
        øvrigKørsel.setAlignment(Pos.CENTER_RIGHT);
        øvrigKørsel.textProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> {
            if (!newValue.matches("\\d*")) {
                øvrigKørsel.setText(newValue.replaceAll("[^\\d]", ""));
            }
    });

        km1 = new Label("km");
        km1.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80), 
            Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
            BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID, 
            BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
            CornerRadii.EMPTY, new BorderWidths(2), Insets.EMPTY)));
        km1.setStyle("-fx-background-color: white");
        km1.setFont(academySansLight18);
        km1.setPrefSize(60, 50);
        km1.setPadding(new Insets(0, 0, 0, 5));
        
        km2 = new Label("km");
        km2.setBorder(new Border(new BorderStroke(Color.rgb(0, 30, 80), 
            Color.rgb(0, 30, 80), Color.rgb(0, 30, 80), Color.rgb(0, 30, 80),
            BorderStrokeStyle.SOLID, BorderStrokeStyle.SOLID, 
            BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,
            CornerRadii.EMPTY, new BorderWidths(2), Insets.EMPTY)));
        km2.setStyle("-fx-background-color: white");
        km2.setFont(academySansLight18);
        km2.setPrefSize(60, 50);        
        km2.setPadding(new Insets(0, 0, 0, 5));
        
        fejlbesked = new Label("Du skal indtaste et helt tal\ni begge felter");
        fejlbesked.setFont(academySansLight18);
        fejlbesked.setTextFill(Color.RED);
        fejlbesked.setVisible(false);
        
        faktaboks = new Label("Vidste du, at en elbils reelle rækkevidde afhænger "
                + "af mange forskellige faktorer? Din kørestil,\ntemperaturen udenfor, hvor meget vægt du har i bilen "
                + ".....");
        faktaboks.setFont(academySansLightItalic18);
        faktaboks.setStyle("-fx-background-color: rgb(0, 30, 80); -fx-text-fill: white; -fx-label-padding: 30;");
        
        centerGrid = new GridPane();
        centerGrid.add(spørgsmål1, 0, 0);
        centerGrid.add(spørgsmål2, 0, 1);
        centerGrid.add(fastKørsel, 1, 0);
        centerGrid.add(km1, 2, 0);
        centerGrid.add(øvrigKørsel, 1, 1);
        centerGrid.add(km2, 2, 1);
        centerGrid.add(fejlbesked, 1, 2);
        centerGrid.add(faktaboks, 0, 3, 3, 1);
        
        centerGrid.setPadding(new Insets(30));
        centerGrid.setVgap(30);
        centerGrid.setMaxWidth(800);
        centerGrid.setStyle("-fx-background-color: white;");
        
        BorderPane.setMargin(centerGrid, new Insets(8, 0, 8, 0));
       
        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setFont(academySansDemiBold16);
        tilbage.setPrefSize(125, 60);
        tilbage.setStyle("-fx-background-color: grey; -fx-text-fill: white;"); 
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide3 forside = new TestSide3();
            getScene().setRoot(forside);
    });
     
        næste = new Button("Næste");
        næste.setFont(academySansDemiBold16);
        næste.setPrefSize(125, 60);
        næste.setStyle("-fx-background-color: rgb(0, 30, 80); -fx-text-fill: white;");
        næste.setOnAction((ActionEvent event) -> {
            if (fastKørsel.getText().isEmpty() || øvrigKørsel.getText().isEmpty()) {
                fejlbesked.setVisible(true);
            } else {
                TestSide9 testside2 = new TestSide9();
                getScene().setRoot(testside2);
            }
        });
        
        knapper = new HBox(tilbage, næste);
        knapper.setAlignment(Pos.CENTER_RIGHT);
        knapper.setPadding(new Insets(12));
        knapper.setSpacing(20);
        knapper.setMaxWidth(800);
        knapper.setStyle("-fx-background-color: white;");
        
        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        setBottom(knapper);
       // this.setStyle("-fx-background-color: lightgrey;");
    }
}
