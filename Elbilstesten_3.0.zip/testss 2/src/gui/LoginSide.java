package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Bruger;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * @author jakobbakhummelgaard
 */
public class LoginSide extends BorderPane {

    TextField brugerFelt;
    PasswordField kodeordFelt;
    Label overskrift, fejlbesked;
    Button login, opretBruger;

    Image close_image;
    ImageView close;

    VBox vboxTop, vbox;

    Bruger loggetInd;

    public Bruger display(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {

        this.loggetInd = bruger;
        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        Stage window = new Stage();
        window.initStyle(StageStyle.TRANSPARENT);

        // Toppen af borderpane
        close_image = new Image(getClass().getResourceAsStream("/billeder/close_icon.png"));
        close = new ImageView(close_image);
        close.setPreserveRatio(true);
        close.setSmooth(true);
        close.setCache(true);

        close.setOnMouseClicked((MouseEvent event) -> {
            window.close();
        });

        vboxTop = new VBox(close);
        vboxTop.getStyleClass().add("vbox-top");

        setTop(vboxTop);

        // Midten af borderpane
        overskrift = new Label("Log ind");
        overskrift.setId("overskrift-label");

        brugerFelt = new TextField();
        brugerFelt.setPromptText("Email");
        brugerFelt.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                vbox.requestFocus();
                firstTime.setValue(false);
            }
        });

        kodeordFelt = new PasswordField();
        kodeordFelt.setPromptText("Kodeord");

        fejlbesked = new Label("Ukendt email eller kodeord");
        fejlbesked.setVisible(false);

        login = new Button("Login");
        login.setOnAction((ActionEvent event) -> {
            if (brugerBase.erOprettet(brugerFelt.getText(), kodeordFelt.getText())) {
                // hent brugeren
                loggetInd = brugerBase.hentBruger(brugerFelt.getText(), kodeordFelt.getText());
                window.close();
            } else {
                fejlbesked.setVisible(true);
            }
        });

        opretBruger = new Button("Opret bruger");
        opretBruger.setId("skift-knap");
        opretBruger.setOnAction((ActionEvent event) -> {
            window.close();
            OpretBruger opret = new OpretBruger();
            loggetInd = opret.display(elbilBase, brugerBase, loggetInd);

        });

        vbox = new VBox(overskrift, brugerFelt, kodeordFelt, fejlbesked, login, opretBruger);
        vbox.getStyleClass().add("vbox");

        setCenter(vbox);

        Scene scene = new Scene(this, 1280, 745);
        scene.setFill(Color.TRANSPARENT);
        scene.getStylesheets().add("/css/brugersider.css");

        window.setScene(scene);
        window.showAndWait();

        return loggetInd;

    }
}
