/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import model.Bruger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.BrugerBase;
import model.Elbil;

/**
 *
 * @author jakobbakhummelgaard
 */
public class OpretBruger extends BorderPane {

    Label overskrift, forklaring, fejlbesked;

    TextField fornavnFelt, efternavnFelt, emailFelt;

    PasswordField kodeordFelt;

    Button opretKnap, loginKnap;

    Image close_image;
    ImageView close;

    VBox vboxTop, vbox;

    GridPane grid;

    Bruger loggetInd;

    public Bruger display(ArrayList<Elbil> elbilBase, BrugerBase brugerBase, Bruger bruger) {
        this.loggetInd = bruger;
        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        Stage window = new Stage();
        window.initStyle(StageStyle.TRANSPARENT);

        // Toppen af borderpane
        close_image = new Image(getClass().getResourceAsStream("/billeder/close_icon.png"));
        close = new ImageView(close_image);
        close.setPreserveRatio(true);
        close.setSmooth(true);
        close.setCache(true);

        close.setOnMouseClicked((MouseEvent event) -> {
            window.close();
        });

        vboxTop = new VBox(close);
        vboxTop.getStyleClass().add("vbox-top");

        setTop(vboxTop);

        // Midten af borderpane
        overskrift = new Label("Opret bruger");
        overskrift.setId("overskrift-label");
        
        forklaring = new Label("Lav en bruger for at tage elbiltesten");
        forklaring.setId("forklaring-label");

        fornavnFelt = new TextField();
        fornavnFelt.setPromptText("Fornavn");
        fornavnFelt.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                vbox.requestFocus();
                firstTime.setValue(false);
            }
        });

        efternavnFelt = new TextField();
        efternavnFelt.setPromptText("Efternavn");

        emailFelt = new TextField();
        emailFelt.setPromptText("Email");

        kodeordFelt = new PasswordField();
        kodeordFelt.setPromptText("Kodeord");

        fejlbesked = new Label("Udfyld alle felter");
        fejlbesked.setVisible(false);

        opretKnap = new Button("Opret bruger");
        opretKnap.setOnAction((ActionEvent event) -> {
            
            if (fornavnFelt.getText().isEmpty() || efternavnFelt.getText().isEmpty()
                    || kodeordFelt.getText().isEmpty()) {
                fejlbesked.setVisible(true);
            } else {
                loggetInd = new Bruger(fornavnFelt.getText(), efternavnFelt.getText(), emailFelt.getText(), kodeordFelt.getText());
                brugerBase.tilføjBruger(loggetInd);
                window.close();
            }
        });
        
        loginKnap = new Button("Log på din konto");
        loginKnap.setId("skift-knap");
        loginKnap.setOnAction((ActionEvent event) -> {
            window.close();
            LoginSide loginSide = new LoginSide();
            loggetInd = loginSide.display(elbilBase, brugerBase, loggetInd);

        });
            
        vbox = new VBox(overskrift, forklaring, fornavnFelt, efternavnFelt, emailFelt,
                kodeordFelt, fejlbesked, opretKnap, loginKnap);
        vbox.getStyleClass().add("vbox");

        setCenter(vbox);

        Scene scene = new Scene(this, 1280, 745);
        scene.setFill(Color.TRANSPARENT);
        scene.getStylesheets().add("/css/brugersider.css");

        window.setScene(scene);
        window.showAndWait();

        return loggetInd;
    }

}
