/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * HUS ELLER LEJLIGHED + PRIMÆR/SEKUNDÆR
 *
 * @author jakobbakhummelgaard
 */
public class TestSide2 extends BorderPane {

    Label overskrift, underoverskrift, spørgsmål1, spørgsmål2, fejlbesked, faktaboks;

    RadioButton hus, lejlighed, primær, sekundær;
    ToggleGroup boliggruppe, bilgruppe;

    Button tilbage, næste;
    
    ProgressBar progressbar;
    AnchorPane anchorPane;
    GridPane centerGrid;
    
    HBox knapper;
    VBox topBox;

    public TestSide2() {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Elbiltesten");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os om din boligsituation");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.250);
        progressbar.setId("progressbar");

        topBox = new VBox(overskrift, underoverskrift, progressbar);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål1 = new Label("Bor du i hus eller lejlighed?");
        spørgsmål2 = new Label("Skal bilen fungere som den primære\neller "
                + "sekundære bil?");

        boliggruppe = new ToggleGroup();
        
        hus = new RadioButton("Hus");
        hus.setToggleGroup(boliggruppe);
        hus.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        lejlighed = new RadioButton("Lejlighed");
        lejlighed.setToggleGroup(boliggruppe);  
        
        bilgruppe = new ToggleGroup();
        
        primær = new RadioButton("Primær");
        primær.setToggleGroup(bilgruppe);
        
        sekundær = new RadioButton("Sekundær");
        sekundær.setToggleGroup(bilgruppe);
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("Bor du i lejlighed skal du være opmærksom på, at "
                + "du ikke nødvendigvis kan oplade en elbil\npå din bopæl. Undersøg "
                + "derfor gerne, om der er ladestandere nær din adresse."); 
        faktaboks.setId("faktaboks-label");

        centerGrid = new GridPane();

        centerGrid = new GridPane();
        
        centerGrid.add(spørgsmål1, 0, 0, 1, 2);
        centerGrid.add(spørgsmål2, 0, 3, 1, 2);
        centerGrid.add(hus, 1, 0);
        centerGrid.add(lejlighed, 1, 1);
        centerGrid.add(primær, 1, 3);
        centerGrid.add(sekundær, 1, 4);     
        centerGrid.add(fejlbesked, 1, 5);
        centerGrid.add(faktaboks, 0, 6, 3, 1);        
        
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        
        centerGrid.setId("centergrid-2");
        
        BorderPane.setMargin(centerGrid, new Insets(8, 0, 8, 0));

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide1 testside1 = new TestSide1();
            getScene().setRoot(testside1);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if ((hus.isSelected() || lejlighed.isSelected()) && (primær.isSelected() || sekundær.isSelected())) {
                TestSide3 testside3 = new TestSide3();
                getScene().setRoot(testside3);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
