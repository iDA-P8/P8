/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * LÆNGERE TURE
 *
 * @author jakobbakhummelgaard
 */
public class TestSide3 extends BorderPane {

    Label overskrift, underoverskrift, spørgsmål, fejlbesked,
            faktaboks;

    RadioButton aldrig, kvartal, måned, ofte;
    ToggleGroup gruppe;

    Button tilbage, næste;

    ProgressBar progressbar;

    GridPane centerGrid;

    HBox knapper;
    VBox topBox;

    public TestSide3() {

        final BooleanProperty firstTime = new SimpleBooleanProperty(true);

        // Top of borderpane
        overskrift = new Label("Elbiltesten");
        overskrift.setId("overskrift");

        underoverskrift = new Label("Fortæl os mere om dit kørselsmønster");
        underoverskrift.setId("underoverskrift");

        progressbar = new ProgressBar(0.375);
        progressbar.setId("progressbar");

        topBox = new VBox(overskrift, underoverskrift, progressbar);
        topBox.getStyleClass().add("vbox");

        BorderPane.setAlignment(topBox, Pos.CENTER);
        BorderPane.setMargin(topBox, new Insets(16, 0, 8, 0));

        setTop(topBox);

        // Midten af borderpane
        spørgsmål = new Label("Du har angivet, at du til dalig kører 125 km."
                + "\n\nHvor ofte kører du længere ture end det?");

        gruppe = new ToggleGroup();
        
        aldrig = new RadioButton("Aldrig");
        aldrig.setToggleGroup(gruppe);
        aldrig.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue && firstTime.get()) {
                centerGrid.requestFocus(); 
                firstTime.setValue(false);
            }
        });
        
        kvartal = new RadioButton("1-4 gange om året");
        kvartal.setToggleGroup(gruppe);  
        
        måned = new RadioButton("1 gang om måneden");
        måned.setToggleGroup(gruppe);  

        ofte = new RadioButton("Flere gange om måneden");
        ofte.setToggleGroup(gruppe);          
        
        fejlbesked = new Label("Du skal vælge én af mulighederne");
        fejlbesked.setId("fejlbesked-label");
        fejlbesked.setVisible(false);

        faktaboks = new Label("Elbilens styrke er ikke at finde på lange ture. "
                + "Når en elbil løber tør for strøm, så tager det meget længere "
                + "tid at lade den op, end det ville tage at tanke en benzin- eller "
                + "dieselbil."); 
        faktaboks.setId("faktaboks-label");

        centerGrid = new GridPane();

        centerGrid = new GridPane();
        centerGrid.add(spørgsmål, 0, 0, 1, 4);
        centerGrid.add(aldrig, 1, 0);
        centerGrid.add(kvartal, 1, 1);
        centerGrid.add(måned, 1, 2);
        centerGrid.add(ofte, 1, 3);     
        centerGrid.add(fejlbesked, 1, 4);
        centerGrid.add(faktaboks, 0, 5, 3, 1);
        
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));
        centerGrid.getColumnConstraints().add(new ColumnConstraints(370));

        centerGrid.setId("centergrid-2");

        BorderPane.setMargin(centerGrid, new Insets(8, 0, 8, 0));

        setCenter(centerGrid);

        //Bunden af borderpane
        tilbage = new Button("Tilbage");
        tilbage.setId("tilbage-knap");
        tilbage.setOnAction((ActionEvent event) -> {
            TestSide2 testside2 = new TestSide2();
            getScene().setRoot(testside2);
        });

        næste = new Button("Næste");
        næste.setOnAction((ActionEvent event) -> {
            if (aldrig.isSelected()) {
                TestSide5 testside5 = new TestSide5();
                getScene().setRoot(testside5);
            } else if (kvartal.isSelected() || måned .isSelected() || 
                    ofte.isSelected()) {
                TestSide4 testside4 = new TestSide4();
                getScene().setRoot(testside4);
            } else {
                fejlbesked.setVisible(true);
            }
        });

        knapper = new HBox(tilbage, næste);
        knapper.getStyleClass().add("hbox");

        BorderPane.setAlignment(knapper, Pos.CENTER);
        BorderPane.setMargin(knapper, new Insets(8, 0, 16, 0));

        this.getStylesheets().add("/css/testsider.css");
        setBottom(knapper);
    }
}
